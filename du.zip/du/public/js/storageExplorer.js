/**
 * Storage Explorer Module
 * Advanced file manager with live search, multi-selection, and deferred upload
 * Supports Termux and Android storage browsing
 */

class StorageExplorer {
  constructor(options = {}) {
    this.onFilesSelected = options.onFilesSelected || (() => {});
    this.onFolderSelected = options.onFolderSelected || (() => {});
    this.onSelectionChange = options.onSelectionChange || (() => {});
    
    // State
    this.currentSource = 'storage';
    this.currentPath = '';
    this.searchQuery = '';
    this.searchResults = [];
    this.isSearching = false;
    this.searchAbortController = null;
    
    // Multi-selection state
    this.selectedItems = new Map(); // path -> {name, type, source, path, size}
    this.multiSelectMode = false;
    this.longPressTimer = null;
    
    // Navigation history
    this.navigationStack = [];
    
    // DOM elements (will be initialized)
    this.elements = {};
    
    // Bind methods
    this.init = this.init.bind(this);
    this.open = this.open.bind(this);
    this.close = this.close.bind(this);
    this.toggle = this.toggle.bind(this);
    this.search = this.search.bind(this);
    this.navigateTo = this.navigateTo.bind(this);
    this.selectItem = this.selectItem.bind(this);
    this.deselectItem = this.deselectItem.bind(this);
    this.clearSelection = this.clearSelection.bind(this);
    this.addToUploadQueue = this.addToUploadQueue.bind(this);
  }

  /**
   * Initialize the storage explorer
   */
  init() {
    this.createUI();
    this.bindEvents();
    this.checkSources();
  }

  /**
   * Create the UI elements
   */
  createUI() {
    // Check if already exists
    if (document.getElementById('storageExplorer')) return;

    const explorerHTML = `
      <div id="storageExplorer" class="storage-explorer">
        <div class="storage-explorer-overlay"></div>
        <div class="storage-explorer-panel glass-panel">
          <!-- Header -->
          <div class="storage-explorer-header">
            <div class="storage-explorer-title">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
              </svg>
              <span>Storage Explorer</span>
            </div>
            <button class="storage-explorer-close" id="storageExplorerClose" title="Close">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>

          <!-- Search Bar Area -->
          <div class="storage-explorer-search-area">
            <!-- Source Toggles -->
            <div class="source-toggles">
              <button class="source-toggle active" data-source="storage" title="Android Storage">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                  <line x1="3" y1="9" x2="21" y2="9"/>
                  <line x1="9" y1="21" x2="9" y2="9"/>
                </svg>
                <span>Storage</span>
              </button>
              <button class="source-toggle" data-source="termux" title="Termux Home">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="4 17 10 11 4 5"/>
                  <line x1="12" y1="19" x2="20" y2="19"/>
                </svg>
                <span>Termux</span>
              </button>
            </div>

            <!-- Search Input -->
            <div class="search-input-container">
              <svg class="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="11" cy="11" r="8"/>
                <path d="M21 21l-4.35-4.35"/>
              </svg>
              <input 
                type="text" 
                id="storageSearchInput" 
                class="storage-search-input" 
                placeholder="Search files or folders..."
                autocomplete="off"
              />
              <button class="search-clear hidden" id="searchClearBtn">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <line x1="18" y1="6" x2="6" y2="18"/>
                  <line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
              <div class="search-loading hidden" id="searchLoading">
                <div class="spinner"></div>
              </div>
            </div>
          </div>

          <!-- Breadcrumb Navigation -->
          <div class="storage-breadcrumb" id="storageBreadcrumb">
            <button class="breadcrumb-item root" data-path="">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
            </button>
          </div>

          <!-- Content Area -->
          <div class="storage-explorer-content">
            <!-- Search Results View -->
            <div class="search-results-view hidden" id="searchResultsView">
              <div class="view-header">
                <span class="view-title">Search Results</span>
                <span class="result-count" id="searchResultCount">0 results</span>
              </div>
              <div class="search-results-list" id="searchResultsList"></div>
            </div>

            <!-- Browser View -->
            <div class="browser-view" id="browserView">
              <div class="browser-sidebar" id="browserSidebar">
                <div class="sidebar-section">
                  <span class="sidebar-label">Quick Access</span>
                  <button class="sidebar-item" data-path="DCIM">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                      <circle cx="8.5" cy="8.5" r="1.5"/>
                      <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    <span>DCIM</span>
                  </button>
                  <button class="sidebar-item" data-path="Download">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                      <polyline points="7 10 12 15 17 10"/>
                      <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    <span>Download</span>
                  </button>
                  <button class="sidebar-item" data-path="Pictures">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                      <circle cx="8.5" cy="8.5" r="1.5"/>
                      <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    <span>Pictures</span>
                  </button>
                  <button class="sidebar-item" data-path="Documents">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                      <polyline points="14 2 14 8 20 8"/>
                      <line x1="16" y1="13" x2="8" y2="13"/>
                      <line x1="16" y1="17" x2="8" y2="17"/>
                      <polyline points="10 9 9 9 8 9"/>
                    </svg>
                    <span>Documents</span>
                  </button>
                  <button class="sidebar-item" data-path="Movies">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/>
                      <line x1="7" y1="2" x2="7" y2="22"/>
                      <line x1="17" y1="2" x2="17" y2="22"/>
                      <line x1="2" y1="12" x2="22" y2="12"/>
                      <line x1="2" y1="7" x2="7" y2="7"/>
                      <line x1="2" y1="17" x2="7" y2="17"/>
                      <line x1="17" y1="17" x2="22" y2="17"/>
                      <line x1="17" y1="7" x2="22" y2="7"/>
                    </svg>
                    <span>Movies</span>
                  </button>
                  <button class="sidebar-item" data-path="Music">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M9 18V5l12-2v13"/>
                      <circle cx="6" cy="18" r="3"/>
                      <circle cx="18" cy="16" r="3"/>
                    </svg>
                    <span>Music</span>
                  </button>
                </div>
              </div>

              <div class="browser-main">
                <div class="browser-list-header">
                  <span class="header-name">Name</span>
                  <span class="header-size">Size</span>
                  <span class="header-actions">Actions</span>
                </div>
                <div class="browser-list" id="browserList">
                  <div class="browser-empty">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
                    </svg>
                    <p>Select a folder to browse</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Selection Panel (Floating) -->
          <div class="selection-panel hidden" id="selectionPanel">
            <div class="selection-panel-header">
              <span class="selection-count" id="selectionCount">0 items selected</span>
              <button class="selection-clear" id="selectionClear">Clear</button>
            </div>
            <div class="selection-list" id="selectionList"></div>
            <div class="selection-actions">
              <button class="btn-add-to-package" id="addToPackageBtn">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                  <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
                <span>Add to Package</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Append to body
    const container = document.createElement('div');
    container.innerHTML = explorerHTML;
    document.body.appendChild(container.firstElementChild);

    // Cache elements
    this.elements = {
      explorer: document.getElementById('storageExplorer'),
      overlay: document.querySelector('.storage-explorer-overlay'),
      panel: document.querySelector('.storage-explorer-panel'),
      closeBtn: document.getElementById('storageExplorerClose'),
      searchInput: document.getElementById('storageSearchInput'),
      searchClearBtn: document.getElementById('searchClearBtn'),
      searchLoading: document.getElementById('searchLoading'),
      breadcrumb: document.getElementById('storageBreadcrumb'),
      searchResultsView: document.getElementById('searchResultsView'),
      browserView: document.getElementById('browserView'),
      searchResultsList: document.getElementById('searchResultsList'),
      searchResultCount: document.getElementById('searchResultCount'),
      browserList: document.getElementById('browserList'),
      browserSidebar: document.getElementById('browserSidebar'),
      selectionPanel: document.getElementById('selectionPanel'),
      selectionCount: document.getElementById('selectionCount'),
      selectionList: document.getElementById('selectionList'),
      selectionClear: document.getElementById('selectionClear'),
      addToPackageBtn: document.getElementById('addToPackageBtn'),
      sourceToggles: document.querySelectorAll('.source-toggle')
    };
  }

  /**
   * Bind event listeners
   */
  bindEvents() {
    // Close button
    this.elements.closeBtn?.addEventListener('click', this.close);
    this.elements.overlay?.addEventListener('click', this.close);

    // Search input
    this.elements.searchInput?.addEventListener('input', (e) => {
      this.searchQuery = e.target.value.trim();
      this.elements.searchClearBtn?.classList.toggle('hidden', !this.searchQuery);
      
      if (this.searchQuery) {
        this.debouncedSearch();
      } else {
        this.clearSearch();
      }
    });

    // Search clear button
    this.elements.searchClearBtn?.addEventListener('click', () => {
      this.elements.searchInput.value = '';
      this.searchQuery = '';
      this.elements.searchClearBtn.classList.add('hidden');
      this.clearSearch();
      this.elements.searchInput.focus();
    });

    // Source toggles
    this.elements.sourceToggles?.forEach(toggle => {
      toggle.addEventListener('click', () => {
        const source = toggle.dataset.source;
        this.switchSource(source);
      });
    });

    // Sidebar navigation
    this.elements.browserSidebar?.querySelectorAll('.sidebar-item').forEach(item => {
      item.addEventListener('click', () => {
        const path = item.dataset.path;
        this.navigateTo(path);
      });
    });

    // Selection panel
    this.elements.selectionClear?.addEventListener('click', this.clearSelection);
    this.elements.addToPackageBtn?.addEventListener('click', () => {
      this.addToUploadQueue();
      this.close();
    });

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen()) {
        this.close();
      }
    });

    // Debounced search
    this.debouncedSearch = this.debounce(() => {
      this.search();
    }, 300);
  }

  /**
   * Check available storage sources
   */
  async checkSources() {
    try {
      const response = await fetch('/api/storage/sources');
      const data = await response.json();
      
      // Update toggle availability
      for (const [key, info] of Object.entries(data.sources)) {
        const toggle = document.querySelector(`.source-toggle[data-source="${key}"]`);
        if (toggle) {
          toggle.disabled = !info.available;
          toggle.classList.toggle('unavailable', !info.available);
          toggle.title = info.available ? toggle.querySelector('span').textContent : `${toggle.querySelector('span').textContent} (Not Available)`;
        }
      }
    } catch (error) {
      console.error('Failed to check storage sources:', error);
    }
  }

  /**
   * Open the storage explorer
   */
  open() {
    this.elements.explorer?.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Load initial directory
    if (!this.currentPath) {
      this.navigateTo('');
    }
    
    // Focus search input
    setTimeout(() => {
      this.elements.searchInput?.focus();
    }, 100);
  }

  /**
   * Close the storage explorer
   */
  close() {
    this.elements.explorer?.classList.remove('active');
    document.body.style.overflow = '';
    
    // Cancel any ongoing search
    if (this.searchAbortController) {
      this.searchAbortController.abort();
      this.searchAbortController = null;
    }
  }

  /**
   * Toggle the storage explorer
   */
  toggle() {
    if (this.isOpen()) {
      this.close();
    } else {
      this.open();
    }
  }

  /**
   * Check if explorer is open
   */
  isOpen() {
    return this.elements.explorer?.classList.contains('active');
  }

  /**
   * Switch storage source
   */
  switchSource(source) {
    if (this.currentSource === source) return;
    
    this.currentSource = source;
    this.currentPath = '';
    this.navigationStack = [];
    
    // Update toggle UI
    this.elements.sourceToggles?.forEach(toggle => {
      toggle.classList.toggle('active', toggle.dataset.source === source);
    });
    
    // Clear search and navigate
    this.clearSearch();
    this.navigateTo('');
  }

  /**
   * Navigate to a directory
   */
  async navigateTo(path) {
    this.currentPath = path;
    
    // Update breadcrumb
    this.updateBreadcrumb();
    
    // Show browser view, hide search results
    this.elements.searchResultsView?.classList.add('hidden');
    this.elements.browserView?.classList.remove('hidden');
    
    // Load directory contents
    await this.loadDirectory();
  }

  /**
   * Update breadcrumb navigation
   */
  updateBreadcrumb() {
    const parts = this.currentPath.split('/').filter(p => p);
    let html = `
      <button class="breadcrumb-item root ${!this.currentPath ? 'active' : ''}" data-path="">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
          <polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
      </button>
    `;
    
    let currentBuildPath = '';
    parts.forEach((part, index) => {
      currentBuildPath += (currentBuildPath ? '/' : '') + part;
      const isLast = index === parts.length - 1;
      html += `
        <span class="breadcrumb-separator">/</span>
        <button class="breadcrumb-item ${isLast ? 'active' : ''}" data-path="${currentBuildPath}">
          ${part}
        </button>
      `;
    });
    
    this.elements.breadcrumb.innerHTML = html;
    
    // Bind breadcrumb clicks
    this.elements.breadcrumb.querySelectorAll('.breadcrumb-item').forEach(item => {
      item.addEventListener('click', () => {
        this.navigateTo(item.dataset.path);
      });
    });
  }

  /**
   * Load directory contents
   */
  async loadDirectory() {
    this.elements.browserList.innerHTML = `
      <div class="browser-loading">
        <div class="spinner"></div>
        <span>Loading...</span>
      </div>
    `;
    
    try {
      const response = await fetch(`/api/storage/list?source=${this.currentSource}&path=${encodeURIComponent(this.currentPath)}`);
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to load directory');
      }
      
      this.renderBrowserList(data.folders, data.files);
    } catch (error) {
      console.error('Failed to load directory:', error);
      this.elements.browserList.innerHTML = `
        <div class="browser-error">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="12" y1="8" x2="12" y2="12"/>
            <line x1="12" y1="16" x2="12.01" y2="16"/>
          </svg>
          <p>Failed to load directory</p>
          <span>${error.message}</span>
        </div>
      `;
    }
  }

  /**
   * Render browser list
   */
  renderBrowserList(folders, files) {
    if (folders.length === 0 && files.length === 0) {
      this.elements.browserList.innerHTML = `
        <div class="browser-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
          </svg>
          <p>This folder is empty</p>
        </div>
      `;
      return;
    }
    
    let html = '';
    
    // Render folders first
    folders.forEach(folder => {
      const isSelected = this.selectedItems.has(folder.path);
      html += `
        <div class="browser-item folder ${isSelected ? 'selected' : ''}" data-path="${folder.path}" data-name="${folder.name}" data-type="folder">
          <div class="item-checkbox ${this.multiSelectMode ? 'visible' : ''}">
            <div class="checkbox ${isSelected ? 'checked' : ''}">
              ${isSelected ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : ''}
            </div>
          </div>
          <div class="item-icon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/>
            </svg>
          </div>
          <div class="item-info">
            <span class="item-name">${folder.name}</span>
            <span class="item-meta">Folder</span>
          </div>
          <div class="item-size">-</div>
          <div class="item-actions">
            <button class="item-btn select-btn" title="Select">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </button>
            <button class="item-btn upload-btn" title="Add to Package">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                <polyline points="17 8 12 3 7 8"/>
                <line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
            </button>
          </div>
        </div>
      `;
    });
    
    // Render files
    files.forEach(file => {
      const isSelected = this.selectedItems.has(file.path);
      html += `
        <div class="browser-item file ${isSelected ? 'selected' : ''}" data-path="${file.path}" data-name="${file.name}" data-type="file" data-size="${file.size}">
          <div class="item-checkbox ${this.multiSelectMode ? 'visible' : ''}">
            <div class="checkbox ${isSelected ? 'checked' : ''}">
              ${isSelected ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : ''}
            </div>
          </div>
          <div class="item-icon">
            ${this.getFileIcon(file.name)}
          </div>
          <div class="item-info">
            <span class="item-name">${file.name}</span>
            <span class="item-meta">${this.formatDate(file.modifiedAt)}</span>
          </div>
          <div class="item-size">${this.formatBytes(file.size)}</div>
          <div class="item-actions">
            <button class="item-btn select-btn" title="Select">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </button>
            <button class="item-btn upload-btn" title="Add to Package">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                <polyline points="17 8 12 3 7 8"/>
                <line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
            </button>
          </div>
        </div>
      `;
    });
    
    this.elements.browserList.innerHTML = html;
    
    // Bind item events
    this.bindItemEvents();
  }

  /**
   * Bind events to browser items
   */
  bindItemEvents() {
    const items = this.elements.browserList.querySelectorAll('.browser-item');
    
    items.forEach(item => {
      const path = item.dataset.path;
      const name = item.dataset.name;
      const type = item.dataset.type;
      const size = parseInt(item.dataset.size || '0');
      
      // Click to navigate (folders) or select (files)
      item.addEventListener('click', (e) => {
        if (e.target.closest('.item-actions') || e.target.closest('.item-checkbox')) {
          return;
        }
        
        if (type === 'folder') {
          this.navigateTo(path);
        } else {
          // Single click file to toggle selection
          this.toggleSelection({ path, name, type, source: this.currentSource, size });
        }
      });
      
      // Long press for multi-select mode
      item.addEventListener('mousedown', () => {
        this.longPressTimer = setTimeout(() => {
          this.enableMultiSelectMode();
          this.toggleSelection({ path, name, type, source: this.currentSource, size });
        }, 500);
      });
      
      item.addEventListener('mouseup', () => {
        clearTimeout(this.longPressTimer);
      });
      
      item.addEventListener('mouseleave', () => {
        clearTimeout(this.longPressTimer);
      });
      
      // Select button
      const selectBtn = item.querySelector('.select-btn');
      selectBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        this.enableMultiSelectMode();
        this.toggleSelection({ path, name, type, source: this.currentSource, size });
      });
      
      // Upload button
      const uploadBtn = item.querySelector('.upload-btn');
      uploadBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (type === 'folder') {
          this.onFolderSelected({ path, name, source: this.currentSource });
        } else {
          this.onFilesSelected([{ path, name, source: this.currentSource, size }]);
        }
      });
    });
  }

  /**
   * Enable multi-select mode
   */
  enableMultiSelectMode() {
    if (this.multiSelectMode) return;
    
    this.multiSelectMode = true;
    this.elements.browserList?.querySelectorAll('.item-checkbox').forEach(cb => {
      cb.classList.add('visible');
    });
  }

  /**
   * Disable multi-select mode
   */
  disableMultiSelectMode() {
    this.multiSelectMode = false;
    this.elements.browserList?.querySelectorAll('.item-checkbox').forEach(cb => {
      cb.classList.remove('visible');
    });
  }

  /**
   * Toggle item selection
   */
  toggleSelection(item) {
    if (this.selectedItems.has(item.path)) {
      this.deselectItem(item.path);
    } else {
      this.selectItem(item);
    }
  }

  /**
   * Select an item
   */
  selectItem(item) {
    this.selectedItems.set(item.path, item);
    this.updateSelectionUI();
    this.onSelectionChange(Array.from(this.selectedItems.values()));
  }

  /**
   * Deselect an item
   */
  deselectItem(path) {
    this.selectedItems.delete(path);
    this.updateSelectionUI();
    this.onSelectionChange(Array.from(this.selectedItems.values()));
  }

  /**
   * Clear all selections
   */
  clearSelection() {
    this.selectedItems.clear();
    this.disableMultiSelectMode();
    this.updateSelectionUI();
    this.onSelectionChange([]);
  }

  /**
   * Update selection UI
   */
  updateSelectionUI() {
    // Update browser items
    this.elements.browserList?.querySelectorAll('.browser-item').forEach(item => {
      const path = item.dataset.path;
      const isSelected = this.selectedItems.has(path);
      item.classList.toggle('selected', isSelected);
      
      const checkbox = item.querySelector('.checkbox');
      if (checkbox) {
        checkbox.classList.toggle('checked', isSelected);
        checkbox.innerHTML = isSelected ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : '';
      }
    });
    
    // Update selection panel
    const count = this.selectedItems.size;
    if (count > 0) {
      this.elements.selectionPanel?.classList.remove('hidden');
      this.elements.selectionCount.textContent = `${count} item${count !== 1 ? 's' : ''} selected`;
      
      // Render selection list
      let html = '';
      this.selectedItems.forEach((item, path) => {
        html += `
          <div class="selection-item" data-path="${path}">
            <div class="selection-item-icon">
              ${item.type === 'folder' 
                ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>'
                : this.getFileIcon(item.name)
              }
            </div>
            <span class="selection-item-name">${item.name}</span>
            <button class="selection-item-remove" data-path="${path}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        `;
      });
      this.elements.selectionList.innerHTML = html;
      
      // Bind remove buttons
      this.elements.selectionList.querySelectorAll('.selection-item-remove').forEach(btn => {
        btn.addEventListener('click', () => {
          this.deselectItem(btn.dataset.path);
        });
      });
    } else {
      this.elements.selectionPanel?.classList.add('hidden');
    }
  }

  /**
   * Search files and folders
   */
  async search() {
    if (!this.searchQuery) {
      this.clearSearch();
      return;
    }
    
    // Cancel previous search
    if (this.searchAbortController) {
      this.searchAbortController.abort();
    }
    this.searchAbortController = new AbortController();
    
    this.isSearching = true;
    this.elements.searchLoading?.classList.remove('hidden');
    
    try {
      const sources = ['storage', 'termux'].join(',');
      const response = await fetch(
        `/api/storage/search?query=${encodeURIComponent(this.searchQuery)}&sources=${sources}&path=`,
        { signal: this.searchAbortController.signal }
      );
      
      const data = await response.json();
      
      if (response.ok) {
        this.searchResults = data.results;
        this.renderSearchResults();
      }
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Search failed:', error);
      }
    } finally {
      this.isSearching = false;
      this.elements.searchLoading?.classList.add('hidden');
    }
  }

  /**
   * Clear search results
   */
  clearSearch() {
    this.searchQuery = '';
    this.searchResults = [];
    this.elements.searchResultsView?.classList.add('hidden');
    this.elements.browserView?.classList.remove('hidden');
  }

  /**
   * Render search results
   */
  renderSearchResults() {
    this.elements.browserView?.classList.add('hidden');
    this.elements.searchResultsView?.classList.remove('hidden');
    
    this.elements.searchResultCount.textContent = `${this.searchResults.length} result${this.searchResults.length !== 1 ? 's' : ''}`;
    
    if (this.searchResults.length === 0) {
      this.elements.searchResultsList.innerHTML = `
        <div class="search-empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"/>
            <path d="M21 21l-4.35-4.35"/>
          </svg>
          <p>No results found for "${this.searchQuery}"</p>
        </div>
      `;
      return;
    }
    
    let html = '';
    this.searchResults.forEach(result => {
      const isSelected = this.selectedItems.has(result.path);
      html += `
        <div class="search-result-item ${isSelected ? 'selected' : ''}" data-path="${result.path}" data-name="${result.name}" data-type="${result.type}" data-source="${result.source}" data-size="${result.size || 0}">
          <div class="result-icon">
            ${result.type === 'folder' 
              ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>'
              : this.getFileIcon(result.name)
            }
          </div>
          <div class="result-info">
            <span class="result-name">${result.name}</span>
            <span class="result-path">${result.path}</span>
          </div>
          <div class="result-meta">
            <span class="result-source">${result.source}</span>
            ${result.size ? `<span class="result-size">${this.formatBytes(result.size)}</span>` : ''}
          </div>
          <div class="result-actions">
            <button class="result-btn select-btn" title="Select">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </button>
            <button class="result-btn upload-btn" title="Add to Package">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                <polyline points="17 8 12 3 7 8"/>
                <line x1="12" y1="3" x2="12" y2="15"/>
              </svg>
            </button>
          </div>
        </div>
      `;
    });
    
    this.elements.searchResultsList.innerHTML = html;
    
    // Bind result events
    this.bindSearchResultEvents();
  }

  /**
   * Bind events to search results
   */
  bindSearchResultEvents() {
    const items = this.elements.searchResultsList.querySelectorAll('.search-result-item');
    
    items.forEach(item => {
      const path = item.dataset.path;
      const name = item.dataset.name;
      const type = item.dataset.type;
      const source = item.dataset.source;
      const size = parseInt(item.dataset.size || '0');
      
      // Select button
      const selectBtn = item.querySelector('.select-btn');
      selectBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        this.enableMultiSelectMode();
        this.toggleSelection({ path, name, type, source, size });
        item.classList.toggle('selected', this.selectedItems.has(path));
      });
      
      // Upload button
      const uploadBtn = item.querySelector('.upload-btn');
      uploadBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        if (type === 'folder') {
          this.onFolderSelected({ path, name, source });
        } else {
          this.onFilesSelected([{ path, name, source, size }]);
        }
      });
      
      // Click to navigate (folders)
      item.addEventListener('click', (e) => {
        if (e.target.closest('.result-actions')) return;
        
        if (type === 'folder') {
          this.currentSource = source;
          this.elements.sourceToggles?.forEach(toggle => {
            toggle.classList.toggle('active', toggle.dataset.source === source);
          });
          this.navigateTo(path);
        }
      });
    });
  }

  /**
   * Add selected items to upload queue
   */
  addToUploadQueue() {
    const items = Array.from(this.selectedItems.values());
    const files = items.filter(i => i.type === 'file');
    const folders = items.filter(i => i.type === 'folder');
    
    if (files.length > 0) {
      this.onFilesSelected(files);
    }
    
    folders.forEach(folder => {
      this.onFolderSelected(folder);
    });
    
    this.clearSelection();
  }

  /**
   * Get file icon based on extension
   */
  getFileIcon(filename) {
    const ext = filename.split('.').pop().toLowerCase();
    
    const icons = {
      // Images
      jpg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
      jpeg: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
      png: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
      gif: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
      webp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
      
      // Videos
      mp4: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>',
      mkv: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>',
      avi: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>',
      mov: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>',
      
      // Audio
      mp3: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
      wav: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
      flac: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
      
      // Code
      js: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      ts: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      css: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      py: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      json: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      
      // Archives
      zip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>',
      rar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>',
      '7z': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>',
      tar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>',
      gz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>',
      
      // Documents
      pdf: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
      doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
      docx: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
      txt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
      md: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>'
    };
    
    return icons[ext] || '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
  }

  /**
   * Format bytes to human readable
   */
  formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  /**
   * Format date
   */
  formatDate(isoString) {
    if (!isoString) return '';
    const date = new Date(isoString);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return date.toLocaleDateString();
  }

  /**
   * Debounce function
   */
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = StorageExplorer;
}
