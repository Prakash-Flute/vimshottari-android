/**
 * AI Workspace Server - Frontend Application
 * Premium prompt packaging and Google Drive integration
 */

class AIWorkspace {
    constructor() {
        this.currentSession = null;
        this.sessions = [];
        this.files = [];
        this.autoSaveTimer = null;
        this.isGenerating = false;
        this.isUploading = false;
        
        // Upload queue for deferred uploads
        this.uploadQueue = {
            files: [],
            folders: []
        };
        
        this.storageExplorer = null;
        this.init();
    }

    async init() {
        this.bindEvents();
        await this.loadSessions();
        
        // Create initial session if none exist
        if (this.sessions.length === 0) {
            await this.createNewSession();
        } else {
            // Load the most recent session
            await this.loadSession(this.sessions[0].id);
        }
        
        this.setupAutoSave();
        this.initStorageExplorer();
    }

    initStorageExplorer() {
        this.storageExplorer = new StorageExplorer({
            onFilesSelected: (files) => this.handleStorageFiles(files),
            onFolderSelected: (folder) => this.handleStorageFolder(folder),
            onSelectionChange: (selection) => this.handleSelectionChange(selection)
        });
        this.storageExplorer.init();
    }

    bindEvents() {
        // File upload
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileInput');

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('drag-over');
        });

        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('drag-over');
        });

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            this.handleFiles(e.dataTransfer.files);
        });

        fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
        });

        // Storage Explorer button
        document.getElementById('storageExplorerBtn')?.addEventListener('click', () => {
            this.storageExplorer?.open();
        });

        // Upload queue actions
        document.getElementById('viewQueueBtn')?.addEventListener('click', () => {
            this.viewUploadQueue();
        });

        document.getElementById('clearQueueBtn')?.addEventListener('click', () => {
            this.clearUploadQueue();
        });

        // Prompt editor
        const promptEditor = document.getElementById('promptEditor');
        promptEditor.addEventListener('input', () => {
            this.updateCharCount();
            this.debounceAutoSave();
            this.updateGenerateButton();
        });

        document.getElementById('clearPrompt').addEventListener('click', () => {
            if (confirm('Are you sure you want to clear the prompt?')) {
                promptEditor.value = '';
                this.updateCharCount();
                this.savePrompt();
                this.updateGenerateButton();
            }
        });

        document.getElementById('saveDraft').addEventListener('click', () => {
            this.savePrompt();
            this.showToast('Draft saved successfully', 'success');
        });

        // Generate button
        document.getElementById('generateBtn').addEventListener('click', () => {
            this.generatePackage();
        });

        // Drive output actions
        document.getElementById('copyLink').addEventListener('click', () => {
            this.copyDriveLink();
        });

        document.getElementById('openDrive').addEventListener('click', () => {
            const link = document.getElementById('driveLink').value;
            if (link) window.open(link, '_blank');
        });

        document.getElementById('newPackage').addEventListener('click', () => {
            this.createNewSession();
        });

        // Session management
        document.getElementById('newSessionBtn').addEventListener('click', () => {
            this.createNewSession();
        });

        document.getElementById('createSessionBtn').addEventListener('click', () => {
            this.createNewSession();
        });

        document.getElementById('sessionToggle').addEventListener('click', () => {
            document.getElementById('sessionsPanel').classList.toggle('collapsed');
        });

        document.getElementById('closeSessions').addEventListener('click', () => {
            document.getElementById('sessionsPanel').classList.add('collapsed');
        });

        // Search
        document.getElementById('searchSessions').addEventListener('input', (e) => {
            this.filterSessions(e.target.value);
        });

        // Theme toggle
        document.getElementById('themeToggle').addEventListener('click', () => {
            document.body.classList.toggle('light-theme');
            localStorage.setItem('theme', document.body.classList.contains('light-theme') ? 'light' : 'dark');
        });

        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'light') {
            document.body.classList.add('light-theme');
        }
    }

    // ====================== STORAGE EXPLORER + QUEUE METHODS ======================

    handleStorageFiles(files) {
        if (!this.currentSession) {
            this.showToast('Please select a session first', 'warning');
            return;
        }
        this.uploadQueue.files.push(...files);
        this.updateQueueUI();
        this.showToast(`${files.length} file(s) added to queue`, 'success');
    }

    handleStorageFolder(folder) {
        if (!this.currentSession) {
            this.showToast('Please select a session first', 'warning');
            return;
        }
        this.uploadQueue.folders.push(folder);
        this.updateQueueUI();
        this.showToast(`Folder "${folder.name}" added to queue`, 'success');
    }

    handleSelectionChange(selection) {
        console.log('Storage selection changed:', selection);
    }

    updateQueueUI() {
        const total = this.uploadQueue.files.length + this.uploadQueue.folders.length;
        const btn = document.getElementById('viewQueueBtn');
        if (btn) btn.textContent = `Queue (${total})`;
    }

    viewUploadQueue() {
        let msg = `📋 Upload Queue\n\n`;
        msg += `Files: ${this.uploadQueue.files.length}\n`;
        msg += `Folders: ${this.uploadQueue.folders.length}\n\n`;

        if (this.uploadQueue.files.length) {
            msg += "Files:\n" + this.uploadQueue.files.map(f => `• ${f.name}`).join("\n") + "\n\n";
        }
        if (this.uploadQueue.folders.length) {
            msg += "Folders:\n" + this.uploadQueue.folders.map(f => `📁 ${f.name}`).join("\n");
        }

        alert(msg);
    }

    clearUploadQueue() {
        if (confirm('Clear entire upload queue?')) {
            this.uploadQueue.files = [];
            this.uploadQueue.folders = [];
            this.updateQueueUI();
            this.showToast('Queue cleared', 'success');
        }
    }

    async processUploadQueue() {
        if (this.uploadQueue.files.length === 0 && this.uploadQueue.folders.length === 0) {
            this.showToast('Queue is empty', 'warning');
            return;
        }

        this.isUploading = true;
        try {
            // Process files
            for (const file of [...this.uploadQueue.files]) {
                await this.uploadStorageFile(file);
            }
            // Process folders
            for (const folder of [...this.uploadQueue.folders]) {
                await this.uploadStorageFolder(folder);
            }

            this.uploadQueue.files = [];
            this.uploadQueue.folders = [];
            this.updateQueueUI();

            this.showToast('All queued files uploaded successfully!', 'success');
        } catch (err) {
            this.showToast('Queue upload failed: ' + err.message, 'error');
        } finally {
            this.isUploading = false;
        }
    }

    async uploadStorageFile(fileInfo) {
        const formData = new FormData();
        formData.append('files', fileInfo);

        const res = await fetch(`/api/sessions/${this.currentSession.id}/files`, {
            method: 'POST',
            body: formData
        });

        if (!res.ok) throw new Error('Upload failed');

        const result = await res.json();
        this.files = result.session.files;
        this.renderFileList();
        this.updateGenerateButton();
    }

    async uploadStorageFolder(folderInfo) {
        if (folderInfo.files && Array.isArray(folderInfo.files)) {
            for (const file of folderInfo.files) {
                await this.uploadStorageFile(file);
            }
        } else {
            this.showToast(`Folder "${folderInfo.name}" processed`, 'success');
        }
    }

    // ====================== ORIGINAL METHODS (FULL) ======================

    async loadSessions() {
        try {
            const response = await fetch('/api/sessions');
            if (!response.ok) throw new Error('Failed to load sessions');
            
            this.sessions = await response.json();
            this.renderSessionsList();
        } catch (error) {
            console.error('Failed to load sessions:', error);
            this.showToast('Failed to load sessions', 'error');
        }
    }

    async loadSession(sessionId) {
        try {
            const response = await fetch(`/api/sessions/${sessionId}`);
            if (!response.ok) throw new Error('Failed to load session');
            
            const session = await response.json();
            this.switchToSession(session);
        } catch (error) {
            console.error('Failed to load session:', error);
            this.showToast('Failed to load session', 'error');
        }
    }

    async createNewSession() {
        try {
            const response = await fetch('/api/sessions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: `Session ${this.sessions.length + 1}` })
            });

            if (!response.ok) throw new Error('Failed to create session');

            const session = await response.json();
            this.sessions.unshift(session);
            this.switchToSession(session);
            this.renderSessionsList();
            
            this.showToast('New session created', 'success');
        } catch (error) {
            console.error('Failed to create session:', error);
            this.showToast('Failed to create session', 'error');
        }
    }

    switchToSession(session) {
        this.currentSession = session;
        this.files = session.files || [];
        
        document.getElementById('currentSessionDisplay').querySelector('.session-name').textContent = session.name;
        document.getElementById('currentSessionDisplay').querySelector('.session-time').textContent = this.formatTime(session.createdAt);
        
        document.getElementById('promptEditor').value = session.prompt || '';
        this.updateCharCount();
        
        this.renderFileList();
        this.updateGenerateButton();
        
        document.getElementById('driveOutput').classList.add('hidden');
        document.getElementById('progressContainer').classList.add('hidden');
        
        document.querySelectorAll('.session-item').forEach(item => {
            item.classList.toggle('active', item.dataset.id === session.id);
        });
    }

    async renameSession(sessionId, newName) {
        if (!newName || !newName.trim()) return;
        
        try {
            const response = await fetch(`/api/sessions/${sessionId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: newName.trim() })
            });

            if (!response.ok) throw new Error('Failed to rename session');

            const updated = await response.json();
            
            const index = this.sessions.findIndex(s => s.id === sessionId);
            if (index !== -1) {
                this.sessions[index].name = updated.name;
            }
            
            if (this.currentSession?.id === sessionId) {
                this.currentSession.name = updated.name;
                document.getElementById('currentSessionDisplay').querySelector('.session-name').textContent = updated.name;
            }
            
            this.renderSessionsList();
            this.showToast('Session renamed', 'success');
        } catch (error) {
            console.error('Failed to rename session:', error);
            this.showToast('Failed to rename session', 'error');
        }
    }

    async deleteSession(sessionId) {
        if (!confirm('Are you sure you want to delete this session? This action cannot be undone.')) {
            return;
        }
        
        try {
            const response = await fetch(`/api/sessions/${sessionId}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ deleteDriveFolder: false })
            });

            if (!response.ok) throw new Error('Failed to delete session');

            this.sessions = this.sessions.filter(s => s.id !== sessionId);
            
            if (this.currentSession?.id === sessionId) {
                if (this.sessions.length > 0) {
                    await this.loadSession(this.sessions[0].id);
                } else {
                    await this.createNewSession();
                }
            }
            
            this.renderSessionsList();
            this.showToast('Session deleted', 'success');
        } catch (error) {
            console.error('Failed to delete session:', error);
            this.showToast('Failed to delete session', 'error');
        }
    }

    async handleFiles(fileList) {
        if (!this.currentSession) return;
        if (this.isUploading) {
            this.showToast('Please wait for current upload to complete', 'warning');
            return;
        }

        this.isUploading = true;
        const formData = new FormData();
        
        for (const file of fileList) {
            formData.append('files', file);
        }

        try {
            this.showToast(`Uploading ${fileList.length} file(s)...`, 'success');
            
            const response = await fetch(`/api/sessions/${this.currentSession.id}/files`, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.message || 'Upload failed');
            }

            const result = await response.json();
            this.files = result.session.files;
            this.renderFileList();
            this.updateGenerateButton();
            
            this.showToast(`${result.uploaded.length} file(s) uploaded successfully`, 'success');
        } catch (error) {
            console.error('Failed to upload files:', error);
            this.showToast('Failed to upload files: ' + error.message, 'error');
        } finally {
            this.isUploading = false;
        }
    }

    async removeFile(filename) {
        if (!confirm(`Are you sure you want to remove "${filename}"?`)) return;
        
        try {
            const response = await fetch(`/api/sessions/\( {this.currentSession.id}/files/ \){encodeURIComponent(filename)}`, {
                method: 'DELETE'
            });

            if (!response.ok) throw new Error('Failed to remove file');

            this.files = this.files.filter(f => f.name !== filename);
            this.renderFileList();
            this.updateGenerateButton();
            
            this.showToast('File removed', 'success');
        } catch (error) {
            console.error('Failed to remove file:', error);
            this.showToast('Failed to remove file', 'error');
        }
    }

    renderFileList() {
        const container = document.getElementById('fileList');
        const countEl = document.getElementById('fileCount');
        
        countEl.textContent = `\( {this.files.length} file \){this.files.length !== 1 ? 's' : ''}`;
        
        if (this.files.length === 0) {
            container.innerHTML = '';
            return;
        }

        container.innerHTML = this.files.map(file => `
            <div class="file-item">
                <div class="file-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                    </svg>
                </div>
                <div class="file-info">
                    <div class="file-name">${this.escapeHtml(file.name)}</div>
                    <div class="file-meta">${this.formatBytes(file.size)}</div>
                </div>
                <button class="file-remove" onclick="workspace.removeFile('${this.escapeHtml(file.name)}')" title="Remove file">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"/>
                        <line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
        `).join('');
    }

    renderSessionsList() {
        const container = document.getElementById('sessionsList');
        
        if (this.sessions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
                    </svg>
                    <p>No sessions yet</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.sessions.map(session => `
            <div class="session-item ${session.id === this.currentSession?.id ? 'active' : ''}" 
                 data-id="${session.id}">
                <div class="session-icon" onclick="workspace.switchToSessionById('${session.id}')">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>
                    </svg>
                </div>
                <div class="session-details" onclick="workspace.switchToSessionById('${session.id}')">
                    <div class="session-title" data-session-id="\( {session.id}"> \){this.escapeHtml(session.name)}</div>
                    <div class="session-meta">${this.formatTime(session.createdAt)} • ${session.fileCount || 0} files</div>
                </div>
                <div class="session-actions">
                    <button class="session-btn" onclick="workspace.startRename('${session.id}')" title="Rename">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                            <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
                        </svg>
                    </button>
                    <button class="session-btn delete" onclick="workspace.deleteSession('${session.id}')" title="Delete">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="3 6 5 6 21 6"/>
                            <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/>
                        </svg>
                    </button>
                </div>
            </div>
        `).join('');
    }

    startRename(sessionId) {
        const titleEl = document.querySelector(`.session-title[data-session-id="${sessionId}"]`);
        if (!titleEl) return;
        
        const currentName = titleEl.textContent;
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'rename-input';
        input.value = currentName;
        
        input.addEventListener('blur', () => {
            this.renameSession(sessionId, input.value);
        });
        
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                input.blur();
            } else if (e.key === 'Escape') {
                titleEl.textContent = currentName;
            }
        });
        
        titleEl.innerHTML = '';
        titleEl.appendChild(input);
        input.focus();
        input.select();
    }

    switchToSessionById(id) {
        const session = this.sessions.find(s => s.id === id);
        if (session) {
            this.switchToSession(session);
        }
    }

    filterSessions(query) {
        const items = document.querySelectorAll('.session-item');
        const lowerQuery = query.toLowerCase();
        
        items.forEach(item => {
            const title = item.querySelector('.session-title').textContent.toLowerCase();
            item.style.display = title.includes(lowerQuery) ? 'flex' : 'none';
        });
    }

    updateCharCount() {
        const count = document.getElementById('promptEditor').value.length;
        document.getElementById('charCount').textContent = `\( {count} character \){count !== 1 ? 's' : ''}`;
    }

    debounceAutoSave() {
        clearTimeout(this.autoSaveTimer);
        const saveStatus = document.getElementById('saveStatus');
        saveStatus.textContent = 'Saving...';
        saveStatus.classList.add('saving');
        this.autoSaveTimer = setTimeout(() => this.savePrompt(), 1000);
    }

    async savePrompt() {
        if (!this.currentSession) return;

        const prompt = document.getElementById('promptEditor').value;
        const saveStatus = document.getElementById('saveStatus');
        
        try {
            const response = await fetch(`/api/sessions/${this.currentSession.id}/prompt`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt })
            });

            if (!response.ok) throw new Error('Failed to save prompt');

            this.currentSession.prompt = prompt;
            saveStatus.textContent = 'Auto-saved';
            saveStatus.classList.remove('saving', 'error');
        } catch (error) {
            console.error('Failed to save prompt:', error);
            saveStatus.textContent = 'Save failed';
            saveStatus.classList.add('error');
        }
    }

    setupAutoSave() {
        // Auto-save is handled by debounce on input
    }

    updateGenerateButton() {
    const hasContent = this.files.length > 0 || 
                      document.getElementById('promptEditor').value.trim().length > 0 ||
                      this.uploadQueue.files.length > 0 ||
                      this.uploadQueue.folders.length > 0;
    btn.disabled = !hasContent || this.isGenerating;
}

    async generatePackage() {
        if (this.isGenerating || !this.currentSession) return;
        this.isGenerating = true;
        this.updateGenerateButton();
        
        // Process upload queue before generating
if (this.uploadQueue.files.length > 0 || this.uploadQueue.folders.length > 0) {
    await this.processUploadQueue();
    this.renderFileList();
}

        const progressContainer = document.getElementById('progressContainer');
        const progressFill = document.getElementById('progressFill');
        const steps = document.querySelectorAll('.step');
        
        progressContainer.classList.remove('hidden');
        document.getElementById('driveOutput').classList.add('hidden');

        const updateProgress = (percent, stepIndex) => {
            progressFill.style.width = `${percent}%`;
            steps.forEach((step, idx) => {
                step.classList.remove('active', 'completed');
                if (idx < stepIndex) step.classList.add('completed');
                else if (idx === stepIndex) step.classList.add('active');
            });
        };

        try {
            updateProgress(20, 0);
            await this.savePrompt();
            updateProgress(40, 1);
            
            const response = await fetch(`/api/sessions/${this.currentSession.id}/generate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });

            updateProgress(80, 2);
            
            const result = await response.json();
            
            if (!response.ok) {
                throw new Error(result.message || result.error || 'Generation failed');
            }
            
            if (result.success) {
                updateProgress(100, 2);
                await this.delay(500);
                
                this.currentSession.driveLink = result.driveLink;
                this.currentSession.driveFolderId = result.driveFolderId;
                document.getElementById('driveLink').value = result.driveLink;
                
                progressContainer.classList.add('hidden');
                document.getElementById('driveOutput').classList.remove('hidden');
                
                this.showToast('Package uploaded to Drive!', 'success');
            } else {
                throw new Error(result.message || 'Generation failed');
            }
        } catch (error) {
            console.error('Failed to generate package:', error);
            this.showToast('Failed to generate package: ' + error.message, 'error');
            progressContainer.classList.add('hidden');
        } finally {
            this.isGenerating = false;
            this.updateGenerateButton();
        }
    }

    copyDriveLink() {
        const linkInput = document.getElementById('driveLink');
        linkInput.select();
        
        try {
            navigator.clipboard.writeText(linkInput.value);
            
            const btn = document.getElementById('copyLink');
            btn.classList.add('copied');
            btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>`;
            
            setTimeout(() => {
                btn.classList.remove('copied');
                btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>`;
            }, 2000);
            
            this.showToast('Link copied to clipboard', 'success');
        } catch (err) {
            document.execCommand('copy');
            this.showToast('Link copied to clipboard', 'success');
        }
    }

    showToast(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const icons = {
            success: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>',
            error: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
            warning: '<svg class="toast-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
        };
        
        toast.innerHTML = `
            ${icons[type] || icons.success}
            <span class="toast-message">${this.escapeHtml(message)}</span>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(100%)';
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // Utilities
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatTime(isoString) {
        const date = new Date(isoString);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return date.toLocaleDateString();
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize application
const workspace = new AIWorkspace();