# AI Workspace Server

A professional local workspace platform for preparing AI prompt packages with seamless Google Drive integration.

![AI Workspace](https://img.shields.io/badge/AI%20Workspace-v1.0.0-blue)
![Node.js](https://img.shields.io/badge/Node.js-16%2B-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Features

- **Session Management**: Create, rename, delete, and switch between unlimited workspace sessions
- **Large File Support**: Upload files up to 10GB with streaming and progress tracking
- **Universal File Formats**: Support for ALL file types - code, images, videos, archives, documents, AI models, and more
- **Google Drive Integration**: Automatic folder creation, file upload, and shareable link generation
- **Modern UI**: Glass-morphism design with smooth animations and responsive layout
- **Real-time Progress**: Visual feedback during uploads and package generation
- **Error Logging**: Comprehensive server-side logging for debugging

## Quick Start

### Prerequisites

- Node.js 16 or higher
- Google Cloud Platform account with Drive API enabled
- OAuth 2.0 credentials

### Installation

1. **Clone or download the project**:
```bash
cd ai-workspace-server
```

2. **Install dependencies**:
```bash
npm install
```

3. **Configure Google Drive API**:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing
   - Enable Google Drive API
   - Create OAuth 2.0 credentials (Desktop application type)
   - Download `credentials.json` and place it in `config/` folder

4. **Start the server**:
```bash
npm start
```

5. **Open in browser**:
```
http://localhost:8080
```

6. **Authenticate with Google Drive**:
   - Click the link in the server console or visit `http://localhost:8080/api/auth/google`
   - Complete OAuth flow
   - Return to the application

## Project Structure

```
ai-workspace-server/
├── server/
│   ├── server.js              # Main entry point
│   ├── routes/
│   │   ├── sessions.js        # Session API routes
│   │   ├── files.js           # File upload routes
│   │   ├── package.js         # Package generation routes
│   │   └── auth.js            # Google OAuth routes
│   ├── controllers/
│   │   ├── sessionController.js
│   │   ├── fileController.js
│   │   └── packageController.js
│   ├── services/
│   │   └── driveService.js    # Google Drive API integration
│   ├── utils/
│   │   ├── logger.js          # Server logging
│   │   └── fileUtils.js       # File operations
│   └── config/
│       └── google-auth.js     # Auth configuration
├── public/
│   ├── index.html             # Main UI
│   ├── css/
│   │   └── styles.css         # Glass-morphism styles
│   └── js/
│       └── app.js             # Frontend application
├── sessions/                  # Session storage
├── uploads/                   # Temporary upload storage
├── config/                    # Configuration files
│   ├── credentials.json       # Google OAuth credentials
│   └── token.json            # Auth tokens (auto-generated)
├── logs/                      # Server logs
├── package.json
└── README.md
```

## API Endpoints

### Sessions

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/sessions` | List all sessions |
| POST | `/api/sessions` | Create new session |
| GET | `/api/sessions/:id` | Get session details |
| PUT | `/api/sessions/:id` | Rename session |
| DELETE | `/api/sessions/:id` | Delete session |
| PUT | `/api/sessions/:id/prompt` | Update prompt |
| POST | `/api/sessions/:id/clone` | Clone session |

### Files

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/sessions/:id/files` | Upload files |
| GET | `/api/sessions/:id/files` | List files |
| DELETE | `/api/sessions/:id/files/:filename` | Delete file |
| GET | `/api/sessions/:id/files/:filename/download` | Download file |

### Package Generation

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/sessions/:id/generate` | Generate package & upload to Drive |
| GET | `/api/sessions/:id/package-status` | Get package status |
| POST | `/api/sessions/:id/zip` | Create ZIP archive |
| GET | `/api/sessions/:id/zip/download` | Download ZIP |

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/auth/google` | Start OAuth flow |
| GET | `/api/auth/google/callback` | OAuth callback |
| GET | `/api/auth/status` | Check auth status |
| POST | `/api/auth/logout` | Revoke authentication |

## Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
PORT=8080
HOST=localhost
NODE_ENV=development
```

### Google Drive Setup

1. **Create OAuth Credentials**:
   - Visit [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
   - Click "Create Credentials" → "OAuth client ID"
   - Select "Desktop app" as application type
   - Name: "AI Workspace Server"
   - Download JSON and save as `config/credentials.json`

2. **Enable Drive API**:
   - Go to [API Library](https://console.cloud.google.com/apis/library)
   - Search for "Google Drive API"
   - Click "Enable"

3. **Configure OAuth Consent Screen**:
   - Go to [OAuth Consent Screen](https://console.cloud.google.com/apis/credentials/consent)
   - Select "External" user type
   - Fill in app name and support email
   - Add scope: `https://www.googleapis.com/auth/drive.file`
   - Add test users if in testing mode

## Usage

### Creating a Package

1. **Create a Session**: Click "New Session" or use the sidebar
2. **Attach Files**: Drag & drop or click to select files (up to 10GB each)
3. **Write Prompt**: Enter your instructions in the prompt editor
4. **Generate Package**: Click "Generate Package" button
5. **Copy Link**: Use the copy button to get the Drive shareable link

### Session Management

- **Switch Sessions**: Click any session in the right sidebar
- **Rename**: Click the pencil icon on a session
- **Delete**: Click the trash icon (confirms before deletion)
- **Search**: Use the search box to filter sessions

### Supported File Types

All file formats are supported, including:

- **Code**: `.js`, `.ts`, `.py`, `.go`, `.java`, `.c`, `.cpp`, `.rs`, `.php`, `.rb`
- **Images**: `.jpg`, `.png`, `.gif`, `.bmp`, `.webp`, `.svg`
- **Videos**: `.mp4`, `.mkv`, `.mov`, `.avi`, `.webm`
- **Archives**: `.zip`, `.rar`, `.7z`, `.tar`, `.gz`
- **Documents**: `.pdf`, `.doc`, `.docx`, `.xls`, `.xlsx`, `.ppt`, `.pptx`
- **Data**: `.json`, `.xml`, `.csv`, `.yaml`
- **AI Models**: `.onnx`, `.pt`, `.pth`, `.safetensors`
- **Binaries**: `.exe`, `.dmg`, `.pkg`, `.apk`

## Troubleshooting

### Google Drive Authentication Issues

**Problem**: "Google Drive not authenticated" error

**Solution**:
1. Visit `http://localhost:8080/api/auth/google`
2. Complete the OAuth flow
3. Check that `config/token.json` was created

### Large File Upload Failures

**Problem**: Upload fails for files > 1GB

**Solution**:
- Ensure sufficient disk space in `uploads/` directory
- Check Node.js memory: `node --max-old-space-size=4096 server/server.js`
- Review server logs in `logs/server.log`

### Session Not Found

**Problem**: "Session not found" error

**Solution**:
- Session may have been deleted
- Create a new session
- Check `sessions/` directory for data

### Drive Upload Failures

**Problem**: Package generation fails at Drive upload

**Solution**:
1. Check authentication: `GET /api/auth/status`
2. Re-authenticate if needed: `GET /api/auth/google`
3. Check server logs for API errors
4. Verify Drive API quota hasn't been exceeded

## Development

### Running in Development Mode

```bash
npm run dev
```

This uses `nodemon` for auto-restart on file changes.

### Server Logs

Logs are stored in `logs/server.log` and include:
- HTTP requests
- File operations
- Drive API calls
- Session management
- Errors and warnings

View logs:
```bash
tail -f logs/server.log
```

### Customization

**Change Port**:
```bash
PORT=3000 npm start
```

**Change Upload Limit**:
Edit `server/controllers/fileController.js`:
```javascript
const MAX_FILE_SIZE = 20 * 1024 * 1024 * 1024; // 20GB
```

## Security Considerations

- Server binds to `localhost` by default (not accessible from network)
- OAuth tokens stored locally in `config/token.json`
- File uploads limited to 10GB per file
- Rate limiting enabled (1000 requests per 15 minutes)
- Helmet.js for security headers

## License

MIT License - see LICENSE file for details

## Contributing

Contributions welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## Support

For issues and questions:
- Check the troubleshooting section
- Review server logs
- Open an issue on GitHub

---

**Built with**: Node.js, Express, Google Drive API, and modern web technologies.
