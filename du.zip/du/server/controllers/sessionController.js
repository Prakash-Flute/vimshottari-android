/**
 * Session Controller
 * Handles all session-related operations including creation,
 * retrieval, updating, deletion, and listing.
 */

const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const driveService = require('../services/driveService');
const {
  createSessionDirectory,
  deleteSessionDirectory,
  writeSessionMeta,
  readSessionMeta,
  updateSessionMeta,
  getAllSessions,
  getSessionFiles,
  readSessionPrompt,
  getSessionSize
} = require('../utils/fileUtils');

/**
 * Create a new session
 * POST /api/sessions
 */
const createSession = async (req, res, next) => {
  try {
    const { name } = req.body;
    
    // Generate unique session ID
    const sessionId = `session_${Date.now()}_${uuidv4().split('-')[0]}`;
    
    // Create session timestamp
    const timestamp = new Date().toISOString();
    
    // Default session name if not provided
    const sessionName = name || `Session ${new Date().toLocaleString()}`;
    
    // Create session directory structure
    await createSessionDirectory(sessionId);
    
    // Create session metadata
    const sessionMeta = {
      id: sessionId,
      name: sessionName,
      createdAt: timestamp,
      updatedAt: timestamp,
      prompt: '',
      files: [],
      driveFolderId: null,
      driveLink: null,
      size: 0
    };
    
    // Save metadata
    await writeSessionMeta(sessionId, sessionMeta);
    
    logger.session('Created', sessionId, sessionName);
    
    res.status(201).json(sessionMeta);
  } catch (error) {
    logger.error('Failed to create session:', error);
    next(error);
  }
};

/**
 * Get all sessions
 * GET /api/sessions
 */
const getSessions = async (req, res, next) => {
  try {
    const sessions = await getAllSessions();
    
    // Enrich sessions with file counts and sizes
    const enrichedSessions = await Promise.all(
      sessions.map(async (session) => {
        const files = await getSessionFiles(session.id);
        const size = await getSessionSize(session.id);
        
        return {
          ...session,
          files,
          fileCount: files.length,
          size
        };
      })
    );
    
    res.json(enrichedSessions);
  } catch (error) {
    logger.error('Failed to get sessions:', error);
    next(error);
  }
};

/**
 * Get a single session by ID
 * GET /api/sessions/:id
 */
const getSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const meta = await readSessionMeta(id);
    
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Get session files
    const files = await getSessionFiles(id);
    const prompt = await readSessionPrompt(id);
    const size = await getSessionSize(id);
    
    const session = {
      ...meta,
      files,
      prompt,
      fileCount: files.length,
      size
    };
    
    res.json(session);
  } catch (error) {
    logger.error('Failed to get session:', error);
    next(error);
  }
};

/**
 * Update session (rename)
 * PUT /api/sessions/:id
 */
const updateSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    const meta = await readSessionMeta(id);
    
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Update name if provided
    if (name && name.trim()) {
      meta.name = name.trim();
      
      // If session has a Drive folder, rename it too
      if (meta.driveFolderId && driveService.isAuthenticated()) {
        try {
          await driveService.drive.files.update({
            fileId: meta.driveFolderId,
            requestBody: { name: name.trim() }
          });
          logger.drive('Renamed folder', `${meta.driveFolderId} -> ${name.trim()}`);
        } catch (driveError) {
          logger.warn('Failed to rename Drive folder:', driveError.message);
          // Continue even if Drive rename fails
        }
      }
    }
    
    // Update metadata
    meta.updatedAt = new Date().toISOString();
    await updateSessionMeta(id, meta);
    
    logger.session('Updated', id, meta.name);
    
    res.json(meta);
  } catch (error) {
    logger.error('Failed to update session:', error);
    next(error);
  }
};

/**
 * Delete a session
 * DELETE /api/sessions/:id
 */
const deleteSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { deleteDriveFolder = false } = req.body;
    
    const meta = await readSessionMeta(id);
    
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Delete Drive folder if requested and exists
    if (deleteDriveFolder && meta.driveFolderId && driveService.isAuthenticated()) {
      try {
        await driveService.deleteFile(meta.driveFolderId);
        logger.drive('Deleted folder', meta.driveFolderId);
      } catch (driveError) {
        logger.warn('Failed to delete Drive folder:', driveError.message);
        // Continue even if Drive deletion fails
      }
    }
    
    // Delete local session directory
    await deleteSessionDirectory(id);
    
    logger.session('Deleted', id, meta.name);
    
    res.json({
      success: true,
      message: 'Session deleted successfully',
      sessionId: id
    });
  } catch (error) {
    logger.error('Failed to delete session:', error);
    next(error);
  }
};

/**
 * Update session prompt
 * PUT /api/sessions/:id/prompt
 */
const updatePrompt = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { prompt } = req.body;
    
    const meta = await readSessionMeta(id);
    
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Update prompt
    const { saveSessionPrompt } = require('../utils/fileUtils');
    await saveSessionPrompt(id, prompt || '');
    
    logger.session('Updated prompt', id, `${(prompt || '').length} characters`);
    
    res.json({
      success: true,
      message: 'Prompt updated successfully',
      sessionId: id,
      promptLength: (prompt || '').length
    });
  } catch (error) {
    logger.error('Failed to update prompt:', error);
    next(error);
  }
};

/**
 * Clone a session
 * POST /api/sessions/:id/clone
 */
const cloneSession = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { name } = req.body;
    
    const sourceMeta = await readSessionMeta(id);
    
    if (!sourceMeta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Create new session
    const newSessionId = `session_${Date.now()}_${uuidv4().split('-')[0]}`;
    const timestamp = new Date().toISOString();
    
    await createSessionDirectory(newSessionId);
    
    // Copy metadata
    const newMeta = {
      id: newSessionId,
      name: name || `${sourceMeta.name} (Copy)`,
      createdAt: timestamp,
      updatedAt: timestamp,
      prompt: sourceMeta.prompt,
      files: [],
      driveFolderId: null,
      driveLink: null,
      size: 0
    };
    
    await writeSessionMeta(newSessionId, newMeta);
    
    // Copy prompt file
    if (sourceMeta.prompt) {
      const { saveSessionPrompt } = require('../utils/fileUtils');
      await saveSessionPrompt(newSessionId, sourceMeta.prompt);
    }
    
    // Copy files
    const sourceFiles = await getSessionFiles(id);
    const fs = require('fs-extra');
    const path = require('path');
    
    for (const file of sourceFiles) {
      const sourcePath = path.join(__dirname, '../../sessions', id, 'files', file.name);
      const destPath = path.join(__dirname, '../../sessions', newSessionId, 'files', file.name);
      
      if (await fs.pathExists(sourcePath)) {
        await fs.copy(sourcePath, destPath);
      }
    }
    
    logger.session('Cloned', `${id} -> ${newSessionId}`, newMeta.name);
    
    res.status(201).json(newMeta);
  } catch (error) {
    logger.error('Failed to clone session:', error);
    next(error);
  }
};

module.exports = {
  createSession,
  getSessions,
  getSession,
  updateSession,
  deleteSession,
  updatePrompt,
  cloneSession
};
