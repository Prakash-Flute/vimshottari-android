/**
 * Package Controller
 * Handles package generation and Google Drive upload operations.
 * Creates a complete package from session files and prompt, then uploads to Drive.
 */

const path = require('path');
const fs = require('fs-extra');
const archiver = require('archiver');
const logger = require('../utils/logger');
const driveService = require('../services/driveService');
const {
  readSessionMeta,
  getSessionFiles,
  getSessionDir,
  getSessionPromptPath,
  updateSessionMeta,
  formatBytes
} = require('../utils/fileUtils');

// Base folder name in Google Drive
const DRIVE_BASE_FOLDER = 'AI_WORKSPACE';

/**
 * Generate package and upload to Google Drive
 * POST /api/sessions/:id/generate
 */
const generatePackage = async (req, res, next) => {
  let packageDir = null;
  
  try {
    const { id } = req.params;
    const { createZip = false } = req.body;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Check if Drive service is authenticated
    if (!driveService.isAuthenticated()) {
      return res.status(503).json({
        error: 'Google Drive not authenticated',
        message: 'Please authenticate with Google Drive first. Visit /api/auth/google'
      });
    }
    
    logger.session('Generating package', id, meta.name);
    
    // Get session files
    const files = await getSessionFiles(id);
    const promptPath = getSessionPromptPath(id);
    const hasPrompt = await fs.pathExists(promptPath);
    
    if (files.length === 0 && !hasPrompt) {
      return res.status(400).json({
        error: 'Empty session',
        message: 'Session has no files or prompt to package.'
      });
    }
    
    // Calculate total size
    const totalSize = files.reduce((sum, f) => sum + f.size, 0);
    logger.info(`Package size: ${formatBytes(totalSize)}, Files: ${files.length}`);
    
    // Step 1: Create or get Drive base folder
    const baseFolder = await getOrCreateBaseFolder();
    logger.drive('Base folder', baseFolder.id);
    
    // Step 2: Create session folder in Drive
    const sessionFolderName = meta.name.replace(/[<>:"/\\|?*]/g, '_');
    const sessionFolder = await driveService.createFolder(sessionFolderName, baseFolder.id);
    logger.drive('Session folder created', sessionFolder.id);
    
    // Step 3: Upload prompt.txt if exists
    if (hasPrompt) {
      await driveService.uploadFile(
        promptPath,
        'prompt.txt',
        sessionFolder.id,
        (progress) => {
          logger.debug(`Prompt upload progress: ${progress}%`);
        }
      );
      logger.file('Uploaded to Drive', 'prompt.txt');
    }
    
    // Step 4: Upload all files
    const uploadedFiles = [];
    for (const file of files) {
      const filePath = path.join(getSessionDir(id), 'files', file.name);
      
      try {
        const uploadedFile = await driveService.uploadFile(
          filePath,
          file.name,
          sessionFolder.id,
          (progress) => {
            logger.debug(`File upload progress (${file.name}): ${progress}%`);
          }
        );
        
        uploadedFiles.push({
          name: file.name,
          id: uploadedFile.id,
          size: file.size
        });
        
        logger.file('Uploaded to Drive', file.name, file.size);
      } catch (uploadError) {
        logger.error(`Failed to upload file ${file.name}:`, uploadError.message);
        // Continue with other files
      }
    }
    
    // Step 5: Get shareable link
    const driveLink = await driveService.getFolderLink(sessionFolder.id);
    logger.drive('Shareable link generated', driveLink);
    
    // Step 6: Update session metadata
    await updateSessionMeta(id, {
      driveFolderId: sessionFolder.id,
      driveLink: driveLink,
      uploadedFiles: uploadedFiles,
      uploadedAt: new Date().toISOString()
    });
    
    logger.session('Package generated', id, `Drive folder: ${sessionFolder.id}`);
    logger.success('Package uploaded to Google Drive successfully');
    
    res.json({
      success: true,
      message: 'Package generated and uploaded successfully',
      driveLink: driveLink,
      driveFolderId: sessionFolder.id,
      sessionId: id,
      filesUploaded: uploadedFiles.length,
      totalSize: formatBytes(totalSize)
    });
    
  } catch (error) {
    logger.error('Failed to generate package:', error);
    next(error);
  }
};

/**
 * Get or create the base AI_WORKSPACE folder in Drive
 */
const getOrCreateBaseFolder = async () => {
  try {
    // Search for existing folder
    const response = await driveService.drive.files.list({
      q: `mimeType='application/vnd.google-apps.folder' and name='${DRIVE_BASE_FOLDER}' and trashed=false`,
      spaces: 'drive',
      fields: 'files(id, name, webViewLink)'
    });
    
    if (response.data.files.length > 0) {
      logger.drive('Found existing base folder', response.data.files[0].id);
      return response.data.files[0];
    }
    
    // Create new folder
    logger.drive('Creating base folder', DRIVE_BASE_FOLDER);
    return await driveService.createFolder(DRIVE_BASE_FOLDER);
    
  } catch (error) {
    logger.error('Failed to get/create base folder:', error.message);
    throw error;
  }
};

/**
 * Create ZIP archive of session
 * POST /api/sessions/:id/zip
 */
const createZipPackage = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    const sessionDir = getSessionDir(id);
    const zipPath = path.join(sessionDir, `${id}.zip`);
    
    // Check if ZIP already exists
    if (await fs.pathExists(zipPath)) {
      const stats = await fs.stat(zipPath);
      return res.json({
        success: true,
        message: 'ZIP archive already exists',
        zipPath: `/api/sessions/${id}/zip/download`,
        size: stats.size,
        createdAt: stats.birthtime.toISOString()
      });
    }
    
    logger.session('Creating ZIP', id);
    
    // Create ZIP archive
    const output = fs.createWriteStream(zipPath);
    const archive = archiver('zip', {
      zlib: { level: 6 } // Compression level
    });
    
    return new Promise((resolve, reject) => {
      output.on('close', async () => {
        const stats = await fs.stat(zipPath);
        logger.success(`ZIP created: ${formatBytes(stats.size)}`);
        
        resolve(res.json({
          success: true,
          message: 'ZIP archive created successfully',
          zipPath: `/api/sessions/${id}/zip/download`,
          size: stats.size,
          createdAt: new Date().toISOString()
        }));
      });
      
      archive.on('error', (err) => {
        logger.error('ZIP creation error:', err);
        reject(next(err));
      });
      
      archive.on('warning', (err) => {
        logger.warn('ZIP creation warning:', err.message);
      });
      
      archive.pipe(output);
      
      // Add prompt.txt
      const promptPath = getSessionPromptPath(id);
      if (fs.pathExistsSync(promptPath)) {
        archive.file(promptPath, { name: 'prompt.txt' });
      }
      
      // Add files directory
      const filesDir = path.join(sessionDir, 'files');
      if (fs.pathExistsSync(filesDir)) {
        archive.directory(filesDir, 'files');
      }
      
      archive.finalize();
    });
    
  } catch (error) {
    logger.error('Failed to create ZIP:', error);
    next(error);
  }
};

/**
 * Download ZIP archive
 * GET /api/sessions/:id/zip/download
 */
const downloadZip = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    const sessionDir = getSessionDir(id);
    const zipPath = path.join(sessionDir, `${id}.zip`);
    
    // Check if ZIP exists
    if (!(await fs.pathExists(zipPath))) {
      return res.status(404).json({
        error: 'ZIP not found',
        message: 'ZIP archive does not exist. Create it first using POST /api/sessions/:id/zip'
      });
    }
    
    const stats = await fs.stat(zipPath);
    
    // Set headers
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Content-Disposition', `attachment; filename="${id}.zip"`);
    
    // Stream file
    const fileStream = fs.createReadStream(zipPath);
    fileStream.pipe(res);
    
    logger.file('ZIP downloaded', `${id}.zip`, stats.size);
    
  } catch (error) {
    logger.error('Failed to download ZIP:', error);
    next(error);
  }
};

/**
 * Get package status
 * GET /api/sessions/:id/package-status
 */
const getPackageStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    const files = await getSessionFiles(id);
    const hasPrompt = await fs.pathExists(getSessionPromptPath(id));
    
    res.json({
      sessionId: id,
      hasFiles: files.length > 0,
      fileCount: files.length,
      hasPrompt,
      isUploaded: !!meta.driveFolderId,
      driveLink: meta.driveLink || null,
      driveFolderId: meta.driveFolderId || null,
      uploadedAt: meta.uploadedAt || null
    });
    
  } catch (error) {
    logger.error('Failed to get package status:', error);
    next(error);
  }
};

module.exports = {
  generatePackage,
  createZipPackage,
  downloadZip,
  getPackageStatus
};
