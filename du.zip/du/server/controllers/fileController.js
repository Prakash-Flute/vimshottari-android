/**
 * File Controller
 * Handles file upload, retrieval, and deletion operations.
 * Supports large files up to 10GB with streaming uploads.
 */

const path = require('path');
const fs = require('fs-extra');
const logger = require('../utils/logger');
const {
  readSessionMeta,
  getSessionFiles,
  saveSessionFile,
  deleteSessionFile,
  getSessionFilesDir,
  sanitizeFilename,
  generateUniqueFilename
} = require('../utils/fileUtils');

// Allowed file types - ALL formats are supported
const ALLOWED_MIME_TYPES = null; // null = accept all

// Maximum file size: 10GB
const MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024; // 10GB in bytes

/**
 * Handle file uploads for a session
 * POST /api/sessions/:id/files
 */
const uploadFiles = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      // Clean up uploaded files
      if (req.files) {
        for (const file of req.files) {
          await fs.remove(file.path);
        }
      }
      
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Check if files were uploaded
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        error: 'No files uploaded',
        message: 'Please select at least one file to upload.'
      });
    }
    
    const uploadedFiles = [];
    const errors = [];
    
    // Get existing files to check for duplicates
    const existingFiles = await getSessionFiles(id);
    const existingNames = existingFiles.map(f => f.name);
    
    // Process each uploaded file
    for (const file of req.files) {
      try {
        // Sanitize filename
        const sanitizedName = sanitizeFilename(file.originalname);
        
        // Generate unique filename if duplicate
        const uniqueName = generateUniqueFilename(sanitizedName, existingNames);
        
        // Save file to session
        const fileInfo = await saveSessionFile(id, uniqueName, file.path);
        
        uploadedFiles.push(fileInfo);
        existingNames.push(uniqueName);
        
        logger.file('Uploaded', uniqueName, file.size);
        
        // Clean up temp file
        await fs.remove(file.path);
        
      } catch (fileError) {
        logger.error('Failed to process file:', file.originalname, fileError.message);
        errors.push({
          filename: file.originalname,
          error: fileError.message
        });
        
        // Clean up temp file
        await fs.remove(file.path);
      }
    }
    
    // Get updated file list
    const updatedFiles = await getSessionFiles(id);
    
    logger.session('Files uploaded', id, `${uploadedFiles.length} files`);
    
    res.json({
      success: true,
      message: `${uploadedFiles.length} file(s) uploaded successfully`,
      session: {
        id,
        files: updatedFiles,
        fileCount: updatedFiles.length
      },
      uploaded: uploadedFiles,
      errors: errors.length > 0 ? errors : undefined
    });
    
  } catch (error) {
    logger.error('Failed to upload files:', error);
    
    // Clean up temp files on error
    if (req.files) {
      for (const file of req.files) {
        await fs.remove(file.path).catch(() => {});
      }
    }
    
    next(error);
  }
};

/**
 * Get all files for a session
 * GET /api/sessions/:id/files
 */
const getFiles = async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    const files = await getSessionFiles(id);
    
    res.json({
      sessionId: id,
      files,
      count: files.length
    });
    
  } catch (error) {
    logger.error('Failed to get files:', error);
    next(error);
  }
};

/**
 * Delete a file from a session
 * DELETE /api/sessions/:id/files/:filename
 */
const deleteFile = async (req, res, next) => {
  try {
    const { id, filename } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Decode filename
    const decodedFilename = decodeURIComponent(filename);
    
    // Delete file
    const deleted = await deleteSessionFile(id, decodedFilename);
    
    if (!deleted) {
      return res.status(404).json({
        error: 'File not found',
        message: `No file found with name: ${decodedFilename}`
      });
    }
    
    // Get updated file list
    const updatedFiles = await getSessionFiles(id);
    
    logger.file('Deleted', decodedFilename);
    logger.session('File deleted', id, decodedFilename);
    
    res.json({
      success: true,
      message: 'File deleted successfully',
      session: {
        id,
        files: updatedFiles,
        fileCount: updatedFiles.length
      }
    });
    
  } catch (error) {
    logger.error('Failed to delete file:', error);
    next(error);
  }
};

/**
 * Download a file from a session
 * GET /api/sessions/:id/files/:filename/download
 */
const downloadFile = async (req, res, next) => {
  try {
    const { id, filename } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Decode filename
    const decodedFilename = decodeURIComponent(filename);
    
    // Get file path
    const filesDir = getSessionFilesDir(id);
    const filePath = path.join(filesDir, decodedFilename);
    
    // Check if file exists
    if (!(await fs.pathExists(filePath))) {
      return res.status(404).json({
        error: 'File not found',
        message: `No file found with name: ${decodedFilename}`
      });
    }
    
    // Get file stats
    const stats = await fs.stat(filePath);
    
    // Set headers
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Content-Disposition', `attachment; filename="${decodedFilename}"`);
    
    // Stream file
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
    
    logger.file('Downloaded', decodedFilename, stats.size);
    
  } catch (error) {
    logger.error('Failed to download file:', error);
    next(error);
  }
};

/**
 * Get file information
 * HEAD /api/sessions/:id/files/:filename
 */
const getFileInfo = async (req, res, next) => {
  try {
    const { id, filename } = req.params;
    
    // Check if session exists
    const meta = await readSessionMeta(id);
    if (!meta) {
      return res.status(404).json({
        error: 'Session not found',
        message: `No session found with ID: ${id}`
      });
    }
    
    // Decode filename
    const decodedFilename = decodeURIComponent(filename);
    
    // Get file path
    const filesDir = getSessionFilesDir(id);
    const filePath = path.join(filesDir, decodedFilename);
    
    // Check if file exists
    if (!(await fs.pathExists(filePath))) {
      return res.status(404).json({
        error: 'File not found',
        message: `No file found with name: ${decodedFilename}`
      });
    }
    
    // Get file stats
    const stats = await fs.stat(filePath);
    
    res.json({
      name: decodedFilename,
      size: stats.size,
      createdAt: stats.birthtime.toISOString(),
      updatedAt: stats.mtime.toISOString(),
      isFile: stats.isFile(),
      isDirectory: stats.isDirectory()
    });
    
  } catch (error) {
    logger.error('Failed to get file info:', error);
    next(error);
  }
};

module.exports = {
  uploadFiles,
  getFiles,
  deleteFile,
  downloadFile,
  getFileInfo,
  MAX_FILE_SIZE,
  ALLOWED_MIME_TYPES
};
