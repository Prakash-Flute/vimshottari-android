/**
 * Google Drive Service
 * Handles all Google Drive API operations including authentication,
 * folder creation, file uploads, and link generation.
 */

const { google } = require('googleapis');
const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');

const CONFIG_DIR = path.join(__dirname, '../../config');
const CREDENTIALS_PATH = path.join(CONFIG_DIR, 'credentials.json');
const TOKEN_PATH = path.join(CONFIG_DIR, 'token.json');

// OAuth2 scopes for Google Drive
const SCOPES = ['https://www.googleapis.com/auth/drive.file'];

class DriveService {
  constructor() {
    this.auth = null;
    this.drive = null;
    this.isInitialized = false;
  }

  /**
   * Initialize the Drive service
   * @returns {Promise<boolean>} True if authenticated, false otherwise
   */
  async initialize() {
    try {
      // Check if credentials exist
      if (!(await fs.pathExists(CREDENTIALS_PATH))) {
        logger.warn('Google Drive credentials not found. Please place credentials.json in config/');
        return false;
      }

      // Load credentials
      const credentials = await fs.readJson(CREDENTIALS_PATH);
      const { client_secret, client_id, redirect_uris } = credentials.installed || credentials.web;

      // Create OAuth2 client
      this.auth = new google.auth.OAuth2(
        client_id,
        client_secret,
        redirect_uris[0]
      );

      // Check for existing token
      if (await fs.pathExists(TOKEN_PATH)) {
        const token = await fs.readJson(TOKEN_PATH);
        this.auth.setCredentials(token);
        
        // Validate token by making a test request
        try {
          this.drive = google.drive({ version: 'v3', auth: this.auth });
          await this.drive.about.get({ fields: 'user' });
          this.isInitialized = true;
          logger.success('Google Drive API authenticated successfully');
          return true;
        } catch (error) {
          logger.warn('Stored token is invalid, re-authentication required');
          await fs.remove(TOKEN_PATH);
        }
      }

      // No valid token found
      logger.warn('Google Drive authentication required');
      logger.info('Please visit: http://localhost:8080/api/auth/google to authenticate');
      return false;
    } catch (error) {
      logger.error('Failed to initialize Drive service:', error.message);
      return false;
    }
  }

  /**
   * Get authentication URL for OAuth2 flow
   * @returns {string} Authorization URL
   */
  getAuthUrl() {
    if (!this.auth) {
      throw new Error('OAuth2 client not initialized');
    }

    return this.auth.generateAuthUrl({
      access_type: 'offline',
      scope: SCOPES,
      prompt: 'consent'
    });
  }

  /**
   * Exchange authorization code for tokens
   * @param {string} code Authorization code
   * @returns {Promise<Object>} Token object
   */
  async exchangeCode(code) {
    if (!this.auth) {
      throw new Error('OAuth2 client not initialized');
    }

    const { tokens } = await this.auth.getToken(code);
    this.auth.setCredentials(tokens);
    
    // Save token
    await fs.writeJson(TOKEN_PATH, tokens);
    
    // Initialize drive API
    this.drive = google.drive({ version: 'v3', auth: this.auth });
    this.isInitialized = true;
    
    logger.success('Google Drive authentication completed');
    return tokens;
  }

  /**
   * Ensure Drive service is initialized
   */
  ensureInitialized() {
    if (!this.isInitialized || !this.drive) {
      throw new Error('Google Drive service not initialized. Please authenticate first.');
    }
  }

  /**
   * Create a folder in Google Drive
   * @param {string} name Folder name
   * @param {string} parentId Parent folder ID (optional)
   * @returns {Promise<Object>} Created folder metadata
   */
  async createFolder(name, parentId = null) {
    this.ensureInitialized();

    const metadata = {
      name: name,
      mimeType: 'application/vnd.google-apps.folder',
      ...(parentId && { parents: [parentId] })
    };

    try {
      logger.drive('Creating folder', name);
      
      const response = await this.drive.files.create({
        requestBody: metadata,
        fields: 'id, name, webViewLink, webContentLink'
      });

      // Set folder permissions to allow anyone with link to view
      await this.drive.permissions.create({
        fileId: response.data.id,
        requestBody: {
          role: 'reader',
          type: 'anyone'
        }
      });

      logger.success(`Folder created: ${name} (${response.data.id})`);
      return response.data;
    } catch (error) {
      logger.error('Failed to create folder:', error.message);
      throw error;
    }
  }

  /**
   * Upload a file to Google Drive
   * @param {string} filePath Local file path
   * @param {string} fileName Name to use in Drive
   * @param {string} parentId Parent folder ID
   * @param {Function} progressCallback Progress callback function
   * @returns {Promise<Object>} Uploaded file metadata
   */
  async uploadFile(filePath, fileName, parentId, progressCallback = null) {
    this.ensureInitialized();

    const stats = await fs.stat(filePath);
    const fileSize = stats.size;

    const metadata = {
      name: fileName,
      parents: parentId ? [parentId] : []
    };

    try {
      logger.drive('Uploading file', `${fileName} (${this.formatBytes(fileSize)})`);

      let response;

      // Use resumable upload for large files (>5MB)
      if (fileSize > 5 * 1024 * 1024) {
        response = await this.uploadLargeFile(filePath, metadata, progressCallback);
      } else {
        response = await this.uploadSmallFile(filePath, metadata);
      }

      // Set file permissions
      await this.drive.permissions.create({
        fileId: response.data.id,
        requestBody: {
          role: 'reader',
          type: 'anyone'
        }
      });

      logger.success(`File uploaded: ${fileName}`);
      return response.data;
    } catch (error) {
      logger.error('Failed to upload file:', error.message);
      throw error;
    }
  }

  /**
   * Upload small file using simple upload
   */
  async uploadSmallFile(filePath, metadata) {
    const media = {
      body: fs.createReadStream(filePath)
    };

    return await this.drive.files.create({
      requestBody: metadata,
      media: media,
      fields: 'id, name, webViewLink, webContentLink, size'
    });
  }

  /**
   * Upload large file using resumable upload
   */
  async uploadLargeFile(filePath, metadata, progressCallback) {
    const fileSize = (await fs.stat(filePath)).size;
    
    // Create resumable upload session
    const resumableUpload = await this.drive.files.create({
      requestBody: metadata,
      media: {
        body: fs.createReadStream(filePath)
      },
      fields: 'id, name, webViewLink, webContentLink, size',
      uploadType: 'resumable'
    }, {
      onUploadProgress: (evt) => {
        const progress = Math.round((evt.bytesRead / fileSize) * 100);
        if (progressCallback) {
          progressCallback(progress);
        }
        logger.debug(`Upload progress: ${progress}%`);
      }
    });

    return resumableUpload;
  }

  /**
   * Upload a directory to Google Drive recursively
   * @param {string} localDir Local directory path
   * @param {string} driveFolderId Parent folder ID in Drive
   * @param {Function} progressCallback Progress callback
   * @returns {Promise<Object>} Upload result
   */
  async uploadDirectory(localDir, driveFolderId, progressCallback = null) {
    this.ensureInitialized();

    const results = {
      folderId: driveFolderId,
      files: [],
      totalSize: 0,
      uploadedSize: 0
    };

    const items = await fs.readdir(localDir);

    for (const item of items) {
      const itemPath = path.join(localDir, item);
      const stats = await fs.stat(itemPath);

      if (stats.isDirectory()) {
        // Create subfolder and upload recursively
        const subfolder = await this.createFolder(item, driveFolderId);
        const subResult = await this.uploadDirectory(itemPath, subfolder.id, progressCallback);
        results.files.push(...subResult.files);
        results.totalSize += subResult.totalSize;
      } else {
        // Upload file
        const fileResult = await this.uploadFile(itemPath, item, driveFolderId, (progress) => {
          if (progressCallback) {
            const overallProgress = Math.round(
              ((results.uploadedSize + (stats.size * progress / 100)) / results.totalSize) * 100
            );
            progressCallback(overallProgress);
          }
        });

        results.files.push({
          name: item,
          id: fileResult.id,
          size: stats.size,
          link: fileResult.webViewLink
        });

        results.uploadedSize += stats.size;
      }

      // Calculate total size
      results.totalSize += stats.size;
    }

    return results;
  }

  /**
   * Get folder shareable link
   * @param {string} folderId Folder ID
   * @returns {Promise<string>} Shareable link
   */
  async getFolderLink(folderId) {
    this.ensureInitialized();

    try {
      const response = await this.drive.files.get({
        fileId: folderId,
        fields: 'webViewLink'
      });

      return response.data.webViewLink;
    } catch (error) {
      logger.error('Failed to get folder link:', error.message);
      throw error;
    }
  }

  /**
   * Delete a file or folder from Drive
   * @param {string} fileId File or folder ID
   */
  async deleteFile(fileId) {
    this.ensureInitialized();

    try {
      await this.drive.files.delete({ fileId });
      logger.drive('Deleted file/folder', fileId);
    } catch (error) {
      logger.error('Failed to delete file:', error.message);
      throw error;
    }
  }

  /**
   * Check if service is authenticated
   * @returns {boolean}
   */
  isAuthenticated() {
    return this.isInitialized && this.drive !== null;
  }

  /**
   * Format bytes to human readable string
   */
  formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }
}

// Export singleton instance
module.exports = new DriveService();
