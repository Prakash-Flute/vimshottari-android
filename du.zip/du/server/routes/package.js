/**
 * Package Routes
 * Handles package generation and Google Drive upload endpoints
 */

const express = require('express');
const router = express.Router({ mergeParams: true });
const packageController = require('../controllers/packageController');

// POST /api/sessions/:id/generate - Generate package and upload to Drive
router.post('/:id/generate', packageController.generatePackage);

// GET /api/sessions/:id/package-status - Get package status
router.get('/:id/package-status', packageController.getPackageStatus);

// POST /api/sessions/:id/zip - Create ZIP archive
router.post('/:id/zip', packageController.createZipPackage);

// GET /api/sessions/:id/zip/download - Download ZIP archive
router.get('/:id/zip/download', packageController.downloadZip);

module.exports = router;
