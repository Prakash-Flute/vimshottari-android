/**
 * Storage Routes
 * Handles filesystem browsing, search, and folder upload operations
 * Supports Termux and Android storage access with security constraints
 */

const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const path = require('path');
const logger = require('../utils/logger');

// Allowed base paths for security
const ALLOWED_PATHS = {
  termux: '/data/data/com.termux/files/home',
  storage: '/storage/emulated/0'
};

// Maximum search results (no artificial limit)
const MAX_SEARCH_RESULTS = 10000;

// Maximum file size for scanning (10GB)
const MAX_FILE_SIZE = 10 * 1024 * 1024 * 1024;

/**
 * Validate and sanitize path to prevent directory traversal
 * @param {string} basePath - Base allowed path
 * @param {string} requestedPath - User requested path
 * @returns {string|null} Sanitized path or null if invalid
 */
const sanitizePath = (basePath, requestedPath) => {
  try {
    // Resolve the absolute path
    const resolvedPath = path.resolve(basePath, requestedPath || '');
    
    // Ensure the resolved path starts with the base path
    if (!resolvedPath.startsWith(basePath)) {
      logger.warn('Path traversal attempt blocked:', requestedPath);
      return null;
    }
    
    return resolvedPath;
  } catch (error) {
    logger.error('Path sanitization error:', error);
    return null;
  }
};

/**
 * Get directory listing
 * GET /api/storage/list?source=termux|storage&path=/sub/path
 */
router.get('/list', async (req, res) => {
  try {
    const { source = 'storage', path: subPath = '' } = req.query;
    
    // Validate source
    if (!ALLOWED_PATHS[source]) {
      return res.status(400).json({
        error: 'Invalid source',
        message: `Source must be one of: ${Object.keys(ALLOWED_PATHS).join(', ')}`
      });
    }
    
    const basePath = ALLOWED_PATHS[source];
    const targetPath = sanitizePath(basePath, subPath);
    
    if (!targetPath) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Invalid or restricted path'
      });
    }
    
    // Check if path exists
    if (!(await fs.pathExists(targetPath))) {
      return res.status(404).json({
        error: 'Path not found',
        message: `Path does not exist: ${subPath}`
      });
    }
    
    const stats = await fs.stat(targetPath);
    if (!stats.isDirectory()) {
      return res.status(400).json({
        error: 'Not a directory',
        message: 'The specified path is not a directory'
      });
    }
    
    // Read directory contents
    const items = await fs.readdir(targetPath, { withFileTypes: true });
    
    const folders = [];
    const files = [];
    
    for (const item of items) {
      // Skip hidden files and system directories
      if (item.name.startsWith('.') || item.name === 'node_modules') {
        continue;
      }
      
      const itemPath = path.join(targetPath, item.name);
      
      try {
        const itemStats = await fs.stat(itemPath);
        
        if (item.isDirectory()) {
          folders.push({
            name: item.name,
            path: path.relative(basePath, itemPath),
            fullPath: itemPath
          });
        } else if (item.isFile()) {
          files.push({
            name: item.name,
            size: itemStats.size,
            path: path.relative(basePath, itemPath),
            fullPath: itemPath,
            modifiedAt: itemStats.mtime.toISOString()
          });
        }
      } catch (err) {
        // Skip items we can't stat (permissions, etc.)
        logger.debug('Skipping item due to stat error:', item.name);
      }
    }
    
    // Sort folders and files alphabetically
    folders.sort((a, b) => a.name.localeCompare(b.name));
    files.sort((a, b) => a.name.localeCompare(b.name));
    
    res.json({
      source,
      path: subPath || '/',
      absolutePath: targetPath,
      folders,
      files,
      folderCount: folders.length,
      fileCount: files.length
    });
    
  } catch (error) {
    logger.error('Failed to list directory:', error);
    res.status(500).json({
      error: 'Failed to list directory',
      message: error.message
    });
  }
});

/**
 * Search files across storage sources
 * GET /api/storage/search?query=term&sources=termux,storage&path=/
 */
router.get('/search', async (req, res) => {
  try {
    const { query = '', sources = 'storage,termux', path: searchPath = '' } = req.query;
    
    if (!query || query.length < 1) {
      return res.status(400).json({
        error: 'Invalid query',
        message: 'Search query must be at least 1 character'
      });
    }
    
    const sourceList = sources.split(',').filter(s => ALLOWED_PATHS[s]);
    
    if (sourceList.length === 0) {
      return res.status(400).json({
        error: 'Invalid sources',
        message: `Sources must be one or more of: ${Object.keys(ALLOWED_PATHS).join(', ')}`
      });
    }
    
    const results = [];
    const lowerQuery = query.toLowerCase();
    
    // Search each source
    for (const source of sourceList) {
      const basePath = ALLOWED_PATHS[source];
      const targetPath = sanitizePath(basePath, searchPath);
      
      if (!targetPath) continue;
      
      try {
        const sourceResults = await searchDirectory(
          targetPath,
          basePath,
          source,
          lowerQuery,
          MAX_SEARCH_RESULTS - results.length
        );
        results.push(...sourceResults);
        
        if (results.length >= MAX_SEARCH_RESULTS) break;
      } catch (err) {
        logger.warn(`Search error in ${source}:`, err.message);
      }
    }
    
    res.json({
      query,
      sources: sourceList,
      results,
      resultCount: results.length,
      truncated: results.length >= MAX_SEARCH_RESULTS
    });
    
  } catch (error) {
    logger.error('Search failed:', error);
    res.status(500).json({
      error: 'Search failed',
      message: error.message
    });
  }
});

/**
 * Recursively search directory for matching files/folders
 */
async function searchDirectory(dirPath, basePath, source, query, maxResults, currentDepth = 0) {
  const results = [];
  
  // Limit recursion depth to prevent stack overflow
  if (currentDepth > 10) return results;
  
  try {
    const items = await fs.readdir(dirPath, { withFileTypes: true });
    
    for (const item of items) {
      if (results.length >= maxResults) break;
      
      // Skip hidden files and system directories
      if (item.name.startsWith('.') || item.name === 'node_modules') {
        continue;
      }
      
      const itemPath = path.join(dirPath, item.name);
      const relativePath = path.relative(basePath, itemPath);
      const nameLower = item.name.toLowerCase();
      
      try {
        const stats = await fs.stat(itemPath);
        
        // Check if name matches query
        const isMatch = nameLower.includes(query);
        
        if (item.isDirectory()) {
          if (isMatch) {
            results.push({
              name: item.name,
              type: 'folder',
              path: relativePath,
              fullPath: itemPath,
              source,
              size: 0,
              modifiedAt: stats.mtime.toISOString()
            });
          }
          
          // Recursively search subdirectories
          const subResults = await searchDirectory(
            itemPath,
            basePath,
            source,
            query,
            maxResults - results.length,
            currentDepth + 1
          );
          results.push(...subResults);
          
        } else if (item.isFile() && isMatch) {
          results.push({
            name: item.name,
            type: 'file',
            path: relativePath,
            fullPath: itemPath,
            source,
            size: stats.size,
            modifiedAt: stats.mtime.toISOString()
          });
        }
      } catch (err) {
        // Skip items we can't access
        logger.debug('Skipping item during search:', item.name);
      }
    }
  } catch (err) {
    logger.debug('Cannot read directory:', dirPath);
  }
  
  return results;
}

/**
 * Get folder contents recursively for upload
 * POST /api/storage/scan-folder
 */
router.post('/scan-folder', async (req, res) => {
  try {
    const { source = 'storage', path: folderPath } = req.body;
    
    if (!folderPath) {
      return res.status(400).json({
        error: 'Missing path',
        message: 'Folder path is required'
      });
    }
    
    if (!ALLOWED_PATHS[source]) {
      return res.status(400).json({
        error: 'Invalid source',
        message: `Source must be one of: ${Object.keys(ALLOWED_PATHS).join(', ')}`
      });
    }
    
    const basePath = ALLOWED_PATHS[source];
    const targetPath = sanitizePath(basePath, folderPath);
    
    if (!targetPath) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Invalid or restricted path'
      });
    }
    
    if (!(await fs.pathExists(targetPath))) {
      return res.status(404).json({
        error: 'Path not found',
        message: `Path does not exist: ${folderPath}`
      });
    }
    
    const stats = await fs.stat(targetPath);
    if (!stats.isDirectory()) {
      return res.status(400).json({
        error: 'Not a directory',
        message: 'The specified path is not a directory'
      });
    }
    
    // Scan folder recursively
    const files = await scanFolderRecursive(targetPath, basePath);
    
    // Calculate total size
    const totalSize = files.reduce((sum, f) => sum + f.size, 0);
    
    res.json({
      source,
      path: folderPath,
      absolutePath: targetPath,
      files,
      fileCount: files.length,
      totalSize
    });
    
  } catch (error) {
    logger.error('Failed to scan folder:', error);
    res.status(500).json({
      error: 'Failed to scan folder',
      message: error.message
    });
  }
});

/**
 * Recursively scan folder and return all files with relative paths
 */
async function scanFolderRecursive(dirPath, basePath, relativePrefix = '') {
  const files = [];
  
  try {
    const items = await fs.readdir(dirPath, { withFileTypes: true });
    
    for (const item of items) {
      // Skip hidden files and system directories
      if (item.name.startsWith('.') || item.name === 'node_modules') {
        continue;
      }
      
      const itemPath = path.join(dirPath, item.name);
      const relativePath = path.join(relativePrefix, item.name);
      
      try {
        const stats = await fs.stat(itemPath);
        
        if (item.isDirectory()) {
          // Recursively scan subdirectory
          const subFiles = await scanFolderRecursive(
            itemPath,
            basePath,
            relativePath
          );
          files.push(...subFiles);
        } else if (item.isFile()) {
          // Skip files that are too large
          if (stats.size > MAX_FILE_SIZE) {
            logger.warn('Skipping large file:', item.name, stats.size);
            continue;
          }
          
          files.push({
            name: item.name,
            relativePath: relativePath,
            fullPath: itemPath,
            size: stats.size,
            modifiedAt: stats.mtime.toISOString()
          });
        }
      } catch (err) {
        logger.debug('Skipping item during scan:', item.name);
      }
    }
  } catch (err) {
    logger.debug('Cannot read directory:', dirPath);
  }
  
  return files;
}

/**
 * Get file info for a single file
 * GET /api/storage/file-info?source=termux|storage&path=/file/path
 */
router.get('/file-info', async (req, res) => {
  try {
    const { source = 'storage', path: filePath } = req.query;
    
    if (!filePath) {
      return res.status(400).json({
        error: 'Missing path',
        message: 'File path is required'
      });
    }
    
    if (!ALLOWED_PATHS[source]) {
      return res.status(400).json({
        error: 'Invalid source',
        message: `Source must be one of: ${Object.keys(ALLOWED_PATHS).join(', ')}`
      });
    }
    
    const basePath = ALLOWED_PATHS[source];
    const targetPath = sanitizePath(basePath, filePath);
    
    if (!targetPath) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Invalid or restricted path'
      });
    }
    
    if (!(await fs.pathExists(targetPath))) {
      return res.status(404).json({
        error: 'File not found',
        message: `File does not exist: ${filePath}`
      });
    }
    
    const stats = await fs.stat(targetPath);
    
    res.json({
      source,
      path: filePath,
      absolutePath: targetPath,
      name: path.basename(filePath),
      size: stats.size,
      isFile: stats.isFile(),
      isDirectory: stats.isDirectory(),
      createdAt: stats.birthtime.toISOString(),
      modifiedAt: stats.mtime.toISOString()
    });
    
  } catch (error) {
    logger.error('Failed to get file info:', error);
    res.status(500).json({
      error: 'Failed to get file info',
      message: error.message
    });
  }
});

/**
 * Stream file download
 * GET /api/storage/download?source=termux|storage&path=/file/path
 */
router.get('/download', async (req, res) => {
  try {
    const { source = 'storage', path: filePath } = req.query;
    
    if (!filePath) {
      return res.status(400).json({
        error: 'Missing path',
        message: 'File path is required'
      });
    }
    
    if (!ALLOWED_PATHS[source]) {
      return res.status(400).json({
        error: 'Invalid source',
        message: `Source must be one of: ${Object.keys(ALLOWED_PATHS).join(', ')}`
      });
    }
    
    const basePath = ALLOWED_PATHS[source];
    const targetPath = sanitizePath(basePath, filePath);
    
    if (!targetPath) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Invalid or restricted path'
      });
    }
    
    if (!(await fs.pathExists(targetPath))) {
      return res.status(404).json({
        error: 'File not found',
        message: `File does not exist: ${filePath}`
      });
    }
    
    const stats = await fs.stat(targetPath);
    
    if (!stats.isFile()) {
      return res.status(400).json({
        error: 'Not a file',
        message: 'The specified path is not a file'
      });
    }
    
    // Set headers for download
    res.setHeader('Content-Length', stats.size);
    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(filePath)}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    
    // Stream file
    const fileStream = fs.createReadStream(targetPath);
    fileStream.pipe(res);
    
    logger.file('Storage download', filePath, stats.size);
    
  } catch (error) {
    logger.error('Failed to download file:', error);
    res.status(500).json({
      error: 'Failed to download file',
      message: error.message
    });
  }
});

/**
 * Get available storage sources
 * GET /api/storage/sources
 */
router.get('/sources', async (req, res) => {
  const sources = {};
  
  for (const [key, basePath] of Object.entries(ALLOWED_PATHS)) {
    try {
      const exists = await fs.pathExists(basePath);
      const stats = exists ? await fs.stat(basePath) : null;
      
      sources[key] = {
        name: key.charAt(0).toUpperCase() + key.slice(1),
        path: basePath,
        available: exists && stats && stats.isDirectory()
      };
    } catch (err) {
      sources[key] = {
        name: key.charAt(0).toUpperCase() + key.slice(1),
        path: basePath,
        available: false
      };
    }
  }
  
  res.json({ sources });
});

module.exports = router;
