/**
 * Session Routes
 * Handles all session-related API endpoints
 */

const express = require('express');
const router = express.Router();
const sessionController = require('../controllers/sessionController');

// GET /api/sessions - Get all sessions
router.get('/', sessionController.getSessions);

// POST /api/sessions - Create a new session
router.post('/', sessionController.createSession);

// GET /api/sessions/:id - Get a specific session
router.get('/:id', sessionController.getSession);

// PUT /api/sessions/:id - Update session (rename)
router.put('/:id', sessionController.updateSession);

// DELETE /api/sessions/:id - Delete a session
router.delete('/:id', sessionController.deleteSession);

// PUT /api/sessions/:id/prompt - Update session prompt
router.put('/:id/prompt', sessionController.updatePrompt);

// POST /api/sessions/:id/clone - Clone a session
router.post('/:id/clone', sessionController.cloneSession);

module.exports = router;
