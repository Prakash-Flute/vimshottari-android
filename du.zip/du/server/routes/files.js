/**
 * File Routes
 * Handles all file-related API endpoints with support for large uploads
 */

const express = require('express');
const router = express.Router({ mergeParams: true });
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');

const fileController = require('../controllers/fileController');
const logger = require('../utils/logger');

// Ensure uploads directory exists
const UPLOADS_DIR = path.join(__dirname, '../../uploads');
fs.ensureDirSync(UPLOADS_DIR);

// Configure multer storage
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    // Create temp directory for this upload
    const tempDir = path.join(UPLOADS_DIR, `temp_${Date.now()}_${uuidv4().split('-')[0]}`);
    await fs.ensureDir(tempDir);
    cb(null, tempDir);
  },
  filename: (req, file, cb) => {
    // Preserve original filename
    cb(null, file.originalname);
  }
});

// Configure multer upload
const upload = multer({
  storage: storage,
  limits: {
    fileSize: fileController.MAX_FILE_SIZE, // 10GB
    files: 100 // Max 100 files per upload
  },
  fileFilter: (req, file, cb) => {
    // Accept all file types - no filtering
    logger.file('Received upload request', file.originalname, file.size);
    cb(null, true);
  }
});

// Middleware to handle multer errors
const handleMulterError = (err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      logger.error('File too large:', err.message);
      return res.status(413).json({
        error: 'File too large',
        message: `File exceeds the maximum allowed size of 10GB.`
      });
    }
    if (err.code === 'LIMIT_FILE_COUNT') {
      logger.error('Too many files:', err.message);
      return res.status(413).json({
        error: 'Too many files',
        message: 'Maximum 100 files allowed per upload.'
      });
    }
    if (err.code === 'LIMIT_UNEXPECTED_FILE') {
      logger.error('Unexpected file field:', err.message);
      return res.status(400).json({
        error: 'Unexpected file field',
        message: 'Invalid file field name. Use "files" as the field name.'
      });
    }
  }
  next(err);
};

// POST /api/sessions/:id/files - Upload files to session
router.post(
  '/:id/files',
  upload.array('files', 100), // Allow up to 100 files
  handleMulterError,
  fileController.uploadFiles
);

// GET /api/sessions/:id/files - Get all files in session
router.get('/:id/files', fileController.getFiles);

// HEAD /api/sessions/:id/files/:filename - Get file info
router.head('/:id/files/:filename', fileController.getFileInfo);

// GET /api/sessions/:id/files/:filename/download - Download a file
router.get('/:id/files/:filename/download', fileController.downloadFile);

// DELETE /api/sessions/:id/files/:filename - Delete a file
router.delete('/:id/files/:filename', fileController.deleteFile);

module.exports = router;
