/**
 * Authentication Routes
 * Handles Google Drive OAuth2 authentication flow
 */

const express = require('express');
const router = express.Router();
const driveService = require('../services/driveService');
const logger = require('../utils/logger');

/**
 * GET /api/auth/google - Start Google OAuth2 flow
 */
router.get('/google', (req, res) => {
  try {
    // Initialize auth client if not already done
    if (!driveService.auth) {
      driveService.initialize().then(() => {
        if (!driveService.auth) {
          return res.status(500).json({
            error: 'OAuth2 not configured',
            message: 'Google Drive credentials not found. Please add credentials.json to config/'
          });
        }
        
        const authUrl = driveService.getAuthUrl();
        res.redirect(authUrl);
      });
    } else {
      const authUrl = driveService.getAuthUrl();
      res.redirect(authUrl);
    }
  } catch (error) {
    logger.error('Failed to start OAuth flow:', error);
    res.status(500).json({
      error: 'Authentication failed',
      message: error.message
    });
  }
});

/**
 * GET /api/auth/google/callback - OAuth2 callback
 */
router.get('/google/callback', async (req, res) => {
  try {
    const { code } = req.query;
    
    if (!code) {
      return res.status(400).json({
        error: 'Missing authorization code',
        message: 'No authorization code received from Google.'
      });
    }
    
    // Exchange code for tokens
    await driveService.exchangeCode(code);
    
    logger.success('Google Drive authentication completed');
    
    // Return success message
    res.send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Authentication Successful</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              display: flex;
              justify-content: center;
              align-items: center;
              min-height: 100vh;
              margin: 0;
              background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
            }
            .container {
              text-align: center;
              background: white;
              padding: 3rem;
              border-radius: 1rem;
              box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            }
            .icon {
              width: 80px;
              height: 80px;
              background: #10b981;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              margin: 0 auto 1.5rem;
            }
            .icon svg {
              width: 40px;
              height: 40px;
              stroke: white;
              stroke-width: 3;
            }
            h1 {
              color: #1f2937;
              margin: 0 0 0.5rem;
            }
            p {
              color: #6b7280;
              margin: 0 0 1.5rem;
            }
            .btn {
              display: inline-block;
              padding: 0.875rem 2rem;
              background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
              color: white;
              text-decoration: none;
              border-radius: 0.5rem;
              font-weight: 500;
              transition: transform 0.2s, box-shadow 0.2s;
            }
            .btn:hover {
              transform: translateY(-2px);
              box-shadow: 0 10px 20px rgba(99, 102, 241, 0.3);
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="icon">
              <svg viewBox="0 0 24 24" fill="none">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            </div>
            <h1>Authentication Successful!</h1>
            <p>Google Drive has been connected successfully.<br>You can now close this window and return to AI Workspace.</p>
            <a href="/" class="btn">Return to AI Workspace</a>
          </div>
        </body>
      </html>
    `);
  } catch (error) {
    logger.error('OAuth callback failed:', error);
    res.status(500).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Authentication Failed</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              display: flex;
              justify-content: center;
              align-items: center;
              min-height: 100vh;
              margin: 0;
              background: linear-gradient(135deg, #ef4444 0%, #f97316 100%);
            }
            .container {
              text-align: center;
              background: white;
              padding: 3rem;
              border-radius: 1rem;
              box-shadow: 0 20px 40px rgba(0,0,0,0.2);
            }
            .icon {
              width: 80px;
              height: 80px;
              background: #ef4444;
              border-radius: 50%;
              display: flex;
              align-items: center;
              justify-content: center;
              margin: 0 auto 1.5rem;
            }
            .icon svg {
              width: 40px;
              height: 40px;
              stroke: white;
              stroke-width: 3;
            }
            h1 {
              color: #1f2937;
              margin: 0 0 0.5rem;
            }
            p {
              color: #6b7280;
              margin: 0 0 1.5rem;
            }
            .error {
              background: #fef2f2;
              color: #dc2626;
              padding: 1rem;
              border-radius: 0.5rem;
              font-family: monospace;
              font-size: 0.875rem;
              margin-bottom: 1.5rem;
            }
            .btn {
              display: inline-block;
              padding: 0.875rem 2rem;
              background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
              color: white;
              text-decoration: none;
              border-radius: 0.5rem;
              font-weight: 500;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="icon">
              <svg viewBox="0 0 24 24" fill="none">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </div>
            <h1>Authentication Failed</h1>
            <p>Could not connect to Google Drive.</p>
            <div class="error">${error.message}</div>
            <a href="/api/auth/google" class="btn">Try Again</a>
          </div>
        </body>
      </html>
    `);
  }
});

/**
 * GET /api/auth/status - Check authentication status
 */
router.get('/status', (req, res) => {
  res.json({
    authenticated: driveService.isAuthenticated(),
    timestamp: new Date().toISOString()
  });
});

/**
 * POST /api/auth/logout - Revoke authentication
 */
router.post('/logout', async (req, res) => {
  try {
    const fs = require('fs-extra');
    const path = require('path');
    const TOKEN_PATH = path.join(__dirname, '../../config/token.json');
    
    if (await fs.pathExists(TOKEN_PATH)) {
      await fs.remove(TOKEN_PATH);
    }
    
    driveService.isInitialized = false;
    driveService.drive = null;
    driveService.auth = null;
    
    logger.info('Google Drive authentication revoked');
    
    res.json({
      success: true,
      message: 'Authentication revoked successfully'
    });
  } catch (error) {
    logger.error('Failed to revoke authentication:', error);
    res.status(500).json({
      error: 'Logout failed',
      message: error.message
    });
  }
});

module.exports = router;
