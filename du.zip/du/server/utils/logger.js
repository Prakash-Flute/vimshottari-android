/**
 * Logger Utility
 * Provides structured logging for server operations
 */

const fs = require('fs-extra');
const path = require('path');

const LOG_DIR = path.join(__dirname, '../../logs');
const LOG_FILE = path.join(LOG_DIR, 'server.log');

// Ensure log directory exists
fs.ensureDirSync(LOG_DIR);

/**
 * Get current timestamp in ISO format
 */
const getTimestamp = () => {
  return new Date().toISOString();
};

/**
 * Format log message
 */
const formatMessage = (level, message, ...args) => {
  const timestamp = getTimestamp();
  const argsStr = args.length > 0 ? ' ' + args.map(arg => 
    typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
  ).join(' ') : '';
  
  return `[${timestamp}] [${level.toUpperCase()}]: ${message}${argsStr}`;
};

/**
 * Write log to file
 */
const writeToFile = async (message) => {
  try {
    await fs.appendFile(LOG_FILE, message + '\n');
  } catch (error) {
    console.error('Failed to write to log file:', error);
  }
};

/**
 * Logger object with different log levels
 */
const logger = {
  /**
   * Log info level message
   */
  info: (message, ...args) => {
    const formatted = formatMessage('INFO', message, ...args);
    console.log('\x1b[36m%s\x1b[0m', formatted); // Cyan color
    writeToFile(formatted);
  },

  /**
   * Log success level message
   */
  success: (message, ...args) => {
    const formatted = formatMessage('SUCCESS', message, ...args);
    console.log('\x1b[32m%s\x1b[0m', formatted); // Green color
    writeToFile(formatted);
  },

  /**
   * Log warning level message
   */
  warn: (message, ...args) => {
    const formatted = formatMessage('WARN', message, ...args);
    console.log('\x1b[33m%s\x1b[0m', formatted); // Yellow color
    writeToFile(formatted);
  },

  /**
   * Log error level message
   */
  error: (message, ...args) => {
    const formatted = formatMessage('ERROR', message, ...args);
    console.log('\x1b[31m%s\x1b[0m', formatted); // Red color
    writeToFile(formatted);
  },

  /**
   * Log debug level message (only in development)
   */
  debug: (message, ...args) => {
    if (process.env.NODE_ENV === 'development') {
      const formatted = formatMessage('DEBUG', message, ...args);
      console.log('\x1b[35m%s\x1b[0m', formatted); // Magenta color
      writeToFile(formatted);
    }
  },

  /**
   * Log HTTP request
   */
  request: (method, path, statusCode, duration) => {
    const formatted = formatMessage('HTTP', `${method} ${path} - ${statusCode} - ${duration}ms`);
    console.log('\x1b[90m%s\x1b[0m', formatted); // Gray color
    writeToFile(formatted);
  },

  /**
   * Log file operation
   */
  file: (operation, filename, size) => {
    const sizeStr = size ? ` (${formatBytes(size)})` : '';
    const formatted = formatMessage('FILE', `${operation}: ${filename}${sizeStr}`);
    console.log('\x1b[34m%s\x1b[0m', formatted); // Blue color
    writeToFile(formatted);
  },

  /**
   * Log Drive operation
   */
  drive: (operation, details) => {
    const formatted = formatMessage('DRIVE', `${operation}: ${details}`);
    console.log('\x1b[94m%s\x1b[0m', formatted); // Light blue color
    writeToFile(formatted);
  },

  /**
   * Log session operation
   */
  session: (operation, sessionId, details = '') => {
    const formatted = formatMessage('SESSION', `${operation}: ${sessionId} ${details}`);
    console.log('\x1b[96m%s\x1b[0m', formatted); // Light cyan color
    writeToFile(formatted);
  },

  /**
   * Get log file path
   */
  getLogPath: () => LOG_FILE,

  /**
   * Clear log file
   */
  clear: async () => {
    try {
      await fs.writeFile(LOG_FILE, '');
      logger.info('Log file cleared');
    } catch (error) {
      console.error('Failed to clear log file:', error);
    }
  }
};

/**
 * Format bytes to human readable string
 */
function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

module.exports = logger;
