/**
 * File Utilities
 * Helper functions for file and directory operations
 */

const fs = require('fs-extra');
const path = require('path');

const SESSIONS_DIR = path.join(__dirname, '../../sessions');
const UPLOADS_DIR = path.join(__dirname, '../../uploads');
const CONFIG_DIR = path.join(__dirname, '../../config');
const LOGS_DIR = path.join(__dirname, '../../logs');

/**
 * Ensure all required directories exist
 */
const ensureDirectories = async () => {
  await fs.ensureDir(SESSIONS_DIR);
  await fs.ensureDir(UPLOADS_DIR);
  await fs.ensureDir(CONFIG_DIR);
  await fs.ensureDir(LOGS_DIR);
};

/**
 * Get session directory path
 */
const getSessionDir = (sessionId) => {
  return path.join(SESSIONS_DIR, sessionId);
};

/**
 * Get session files directory path
 */
const getSessionFilesDir = (sessionId) => {
  return path.join(SESSIONS_DIR, sessionId, 'files');
};

/**
 * Get session metadata file path
 */
const getSessionMetaPath = (sessionId) => {
  return path.join(SESSIONS_DIR, sessionId, 'meta.json');
};

/**
 * Get session prompt file path
 */
const getSessionPromptPath = (sessionId) => {
  return path.join(SESSIONS_DIR, sessionId, 'prompt.txt');
};

/**
 * Create a new session directory structure
 */
const createSessionDirectory = async (sessionId) => {
  const sessionDir = getSessionDir(sessionId);
  const filesDir = getSessionFilesDir(sessionId);
  
  await fs.ensureDir(sessionDir);
  await fs.ensureDir(filesDir);
  
  return { sessionDir, filesDir };
};

/**
 * Delete a session directory
 */
const deleteSessionDirectory = async (sessionId) => {
  const sessionDir = getSessionDir(sessionId);
  await fs.remove(sessionDir);
};

/**
 * Read session metadata
 */
const readSessionMeta = async (sessionId) => {
  const metaPath = getSessionMetaPath(sessionId);
  
  if (!(await fs.pathExists(metaPath))) {
    return null;
  }
  
  try {
    const data = await fs.readJson(metaPath);
    return data;
  } catch (error) {
    return null;
  }
};

/**
 * Write session metadata
 */
const writeSessionMeta = async (sessionId, meta) => {
  const metaPath = getSessionMetaPath(sessionId);
  await fs.writeJson(metaPath, meta, { spaces: 2 });
};

/**
 * Update session metadata
 */
const updateSessionMeta = async (sessionId, updates) => {
  const meta = await readSessionMeta(sessionId) || {};
  const updated = { ...meta, ...updates, updatedAt: new Date().toISOString() };
  await writeSessionMeta(sessionId, updated);
  return updated;
};

/**
 * Get all sessions
 */
const getAllSessions = async () => {
  if (!(await fs.pathExists(SESSIONS_DIR))) {
    return [];
  }
  
  const sessionDirs = await fs.readdir(SESSIONS_DIR);
  const sessions = [];
  
  for (const dir of sessionDirs) {
    const meta = await readSessionMeta(dir);
    if (meta) {
      sessions.push(meta);
    }
  }
  
  // Sort by createdAt descending
  return sessions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
};

/**
 * Get session files
 */
const getSessionFiles = async (sessionId) => {
  const filesDir = getSessionFilesDir(sessionId);
  
  if (!(await fs.pathExists(filesDir))) {
    return [];
  }
  
  const files = await fs.readdir(filesDir);
  const fileDetails = [];
  
  for (const filename of files) {
    const filePath = path.join(filesDir, filename);
    const stats = await fs.stat(filePath);
    
    fileDetails.push({
      name: filename,
      size: stats.size,
      createdAt: stats.birthtime.toISOString(),
      updatedAt: stats.mtime.toISOString()
    });
  }
  
  return fileDetails;
};

/**
 * Save file to session
 */
const saveSessionFile = async (sessionId, filename, sourcePath) => {
  const filesDir = getSessionFilesDir(sessionId);
  const destPath = path.join(filesDir, filename);
  
  await fs.copy(sourcePath, destPath);
  
  const stats = await fs.stat(destPath);
  return {
    name: filename,
    size: stats.size,
    createdAt: stats.birthtime.toISOString(),
    updatedAt: stats.mtime.toISOString()
  };
};

/**
 * Delete file from session
 */
const deleteSessionFile = async (sessionId, filename) => {
  const filesDir = getSessionFilesDir(sessionId);
  const filePath = path.join(filesDir, filename);
  
  if (await fs.pathExists(filePath)) {
    await fs.remove(filePath);
    return true;
  }
  
  return false;
};

/**
 * Save prompt to session
 */
const saveSessionPrompt = async (sessionId, prompt) => {
  const promptPath = getSessionPromptPath(sessionId);
  await fs.writeFile(promptPath, prompt, 'utf8');
  
  // Update metadata
  await updateSessionMeta(sessionId, { prompt });
  
  return promptPath;
};

/**
 * Read prompt from session
 */
const readSessionPrompt = async (sessionId) => {
  const promptPath = getSessionPromptPath(sessionId);
  
  if (!(await fs.pathExists(promptPath))) {
    return '';
  }
  
  return await fs.readFile(promptPath, 'utf8');
};

/**
 * Get session total size
 */
const getSessionSize = async (sessionId) => {
  const sessionDir = getSessionDir(sessionId);
  
  if (!(await fs.pathExists(sessionDir))) {
    return 0;
  }
  
  let totalSize = 0;
  
  const calculateSize = async (dir) => {
    const items = await fs.readdir(dir);
    
    for (const item of items) {
      const itemPath = path.join(dir, item);
      const stats = await fs.stat(itemPath);
      
      if (stats.isDirectory()) {
        await calculateSize(itemPath);
      } else {
        totalSize += stats.size;
      }
    }
  };
  
  await calculateSize(sessionDir);
  return totalSize;
};

/**
 * Copy directory recursively
 */
const copyDirectory = async (source, destination) => {
  await fs.copy(source, destination, {
    filter: (src) => {
      // Skip hidden files and node_modules
      const basename = path.basename(src);
      return !basename.startsWith('.') && basename !== 'node_modules';
    }
  });
};

/**
 * Format bytes to human readable string
 */
const formatBytes = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

/**
 * Sanitize filename
 */
const sanitizeFilename = (filename) => {
  return filename
    .replace(/[<>:"/\\|?*]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .substring(0, 255);
};

/**
 * Generate unique filename
 */
const generateUniqueFilename = (originalName, existingNames = []) => {
  const ext = path.extname(originalName);
  const base = path.basename(originalName, ext);
  
  let uniqueName = originalName;
  let counter = 1;
  
  while (existingNames.includes(uniqueName)) {
    uniqueName = `${base} (${counter})${ext}`;
    counter++;
  }
  
  return uniqueName;
};

module.exports = {
  SESSIONS_DIR,
  UPLOADS_DIR,
  CONFIG_DIR,
  LOGS_DIR,
  ensureDirectories,
  getSessionDir,
  getSessionFilesDir,
  getSessionMetaPath,
  getSessionPromptPath,
  createSessionDirectory,
  deleteSessionDirectory,
  readSessionMeta,
  writeSessionMeta,
  updateSessionMeta,
  getAllSessions,
  getSessionFiles,
  saveSessionFile,
  deleteSessionFile,
  saveSessionPrompt,
  readSessionPrompt,
  getSessionSize,
  copyDirectory,
  formatBytes,
  sanitizeFilename,
  generateUniqueFilename
};
