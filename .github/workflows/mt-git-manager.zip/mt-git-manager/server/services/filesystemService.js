// server/services/filesystemService.js
const fs = require('fs').promises;
const path = require('path');
const pathUtils = require('../utils/pathUtils');

const BASE_PATH = '/';

class FilesystemService {
    constructor() {
        this.basePath = BASE_PATH;
    }

    // Ensure path is valid (removed sandbox restriction)
    sanitizePath(inputPath) {
        // Normalize path
        let normalized = path.normalize(inputPath);

        // Resolve absolute path
        normalized = path.resolve(normalized);

        // If relative path, join with current working directory
        if (!normalized.startsWith('/')) {
            normalized = path.join(process.cwd(), normalized);
        }

        return normalized;
    }

    async listDirectory(dirPath) {
        const safePath = this.sanitizePath(dirPath);

        try {
            const entries = await fs.readdir(safePath, { withFileTypes: true });

            const files = await Promise.all(entries.map(async (entry) => {
                const fullPath = path.join(safePath, entry.name);
                const stats = await fs.stat(fullPath).catch(() => null);

                return {
                    name: entry.name,
                    type: entry.isDirectory() ? 'directory' : 'file',
                    size: stats ? stats.size : 0,
                    modified: stats ? stats.mtime.toISOString() : new Date().toISOString(),
                    permissions: stats ? stats.mode.toString(8) : 'unknown'
                };
            }));

            // Sort: directories first, then alphabetically
            return files.sort((a, b) => {
                if (a.type === b.type) return a.name.localeCompare(b.name);
                return a.type === 'directory' ? -1 : 1;
            });
        } catch (error) {
            throw new Error(`Cannot read directory: ${error.message}`);
        }
    }

    async readFile(filePath) {
        const safePath = this.sanitizePath(filePath);

        try {
            // Check if file is binary (images, etc.)
            const ext = path.extname(safePath).toLowerCase();
            const binaryExts = ['.png', '.jpg', '.jpeg', '.gif', '.ico', '.pdf', '.zip', '.mp4', '.mp3', '.webm'];

            if (binaryExts.includes(ext)) {
                return await fs.readFile(safePath);
            }

            return await fs.readFile(safePath, 'utf-8');
        } catch (error) {
            throw new Error(`Cannot read file: ${error.message}`);
        }
    }

    async writeFile(filePath, content) {
        const safePath = this.sanitizePath(filePath);

        try {
            // Ensure directory exists
            const dir = path.dirname(safePath);
            await fs.mkdir(dir, { recursive: true });

            await fs.writeFile(safePath, content, 'utf-8');
            return true;
        } catch (error) {
            throw new Error(`Cannot write file: ${error.message}`);
        }
    }

    async deleteFile(filePath) {
        const safePath = this.sanitizePath(filePath);

        try {
            const stats = await fs.stat(safePath);

            if (stats.isDirectory()) {
                await fs.rmdir(safePath, { recursive: true });
            } else {
                await fs.unlink(safePath);
            }

            return true;
        } catch (error) {
            throw new Error(`Cannot delete: ${error.message}`);
        }
    }

    async renameFile(oldPath, newPath) {
        const safeOld = this.sanitizePath(oldPath);
        const safeNew = this.sanitizePath(newPath);

        try {
            await fs.rename(safeOld, safeNew);
            return true;
        } catch (error) {
            throw new Error(`Cannot rename: ${error.message}`);
        }
    }

    async createDirectory(dirPath) {
        const safePath = this.sanitizePath(dirPath);

        try {
            await fs.mkdir(safePath, { recursive: true });
            return true;
        } catch (error) {
            throw new Error(`Cannot create directory: ${error.message}`);
        }
    }

    async fileExists(filePath) {
        try {
            const safePath = this.sanitizePath(filePath);
            await fs.access(safePath);
            return true;
        } catch {
            return false;
        }
    }

    async getFileStats(filePath) {
        const safePath = this.sanitizePath(filePath);
        return await fs.stat(safePath);
    }

    // New: Get available storage locations
    async getSystemRoots() {
        return [
            { path: '/', name: 'Root Filesystem' },
            { path: '/storage/emulated/0', name: 'Internal Storage' },
            { path: '/data/data/com.termux/files/home', name: 'Termux Home' },
            { path: '/sdcard', name: 'SD Card' },
            { path: '/system', name: 'System (Read-only)' },
            { path: '/vendor', name: 'Vendor (Read-only)' },
            { path: process.cwd(), name: 'Current Working Directory' }
        ];
    }
}

module.exports = new FilesystemService();
