// server/services/githubService.js
const https = require('https');

class GitHubService {
    constructor() {
        this.token = null;
        this.repo = null;
        this.owner = null;
        this.repoName = null;
        this.apiBase = 'api.github.com';
    }

    setCredentials(token, repo) {
        this.token = token;
        this.repo = repo;
        
        // Parse owner/repo format
        const parts = repo.split('/');
        if (parts.length !== 2) {
            throw new Error('Repository must be in format "owner/repo"');
        }
        this.owner = parts[0];
        this.repoName = parts[1];
    }

    isConnected() {
        return !!(this.token && this.repo && this.owner && this.repoName);
    }

    // Make authenticated request to GitHub API
    async request(path, method = 'GET', data = null) {
        return new Promise((resolve, reject) => {
            const options = {
                hostname: this.apiBase,
                path: path,
                method: method,
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Accept': 'application/vnd.github+json',
                    'User-Agent': 'MT-Git-Manager/1.0',
                    'X-GitHub-Api-Version': '2022-11-28'
                }
            };

            if (data) {
                options.headers['Content-Type'] = 'application/json';
            }

            const req = https.request(options, (res) => {
                let body = '';
                res.on('data', chunk => body += chunk);
                res.on('end', () => {
                    try {
                        const parsed = JSON.parse(body);
                        if (res.statusCode >= 200 && res.statusCode < 300) {
                            resolve(parsed);
                        } else {
                            reject(new Error(parsed.message || `HTTP ${res.statusCode}`));
                        }
                    } catch (e) {
                        reject(new Error('Invalid JSON response'));
                    }
                });
            });

            req.on('error', (err) => reject(err));

            if (data) {
                req.write(JSON.stringify(data));
            }
            
            req.end();
        });
    }

    async validateConnection(token, repo) {
        // Temporarily set credentials for validation
        const prevToken = this.token;
        const prevRepo = this.repo;
        
        this.token = token;
        this.repo = repo;
        const parts = repo.split('/');
        this.owner = parts[0];
        this.repoName = parts[1];
        
        try {
            const result = await this.request(`/repos/${this.owner}/${this.repoName}`);
            return result;
        } catch (error) {
            // Restore previous credentials on failure
            this.token = prevToken;
            this.repo = prevRepo;
            this.owner = null;
            this.repoName = null;
            throw error;
        }
    }

    async listContents(path = '') {
        const url = `/repos/${this.owner}/${this.repoName}/contents/${path}?ref=main`;
        const data = await this.request(url);
        
        // Handle both array (directory) and object (single file) responses
        const items = Array.isArray(data) ? data : [data];
        
        return items.map(item => ({
            name: item.name,
            type: item.type === 'dir' ? 'directory' : 'file',
            path: item.path,
            sha: item.sha,
            size: item.size || 0,
            download_url: item.download_url,
            html_url: item.html_url
        }));
    }

    async getFileContent(path) {
        const url = `/repos/${this.owner}/${this.repoName}/contents/${path}?ref=main`;
        const data = await this.request(url);
        
        if (data.content) {
            // Decode base64 content
            return Buffer.from(data.content, 'base64').toString('utf-8');
        }
        
        throw new Error('No content in response');
    }

    async getFileInfo(path) {
        const url = `/repos/${this.owner}/${this.repoName}/contents/${path}?ref=main`;
        return await this.request(url);
    }

    async createFile(path, content, message) {
        const url = `/repos/${this.owner}/${this.repoName}/contents/${path}`;
        
        // Encode content to base64
        const encodedContent = Buffer.from(content).toString('base64');
        
        const data = {
            message: message,
            content: encodedContent,
            branch: 'main'
        };

        return await this.request(url, 'PUT', data);
    }

    async updateFile(path, content, sha, message) {
        const url = `/repos/${this.owner}/${this.repoName}/contents/${path}`;
        
        const encodedContent = Buffer.from(content).toString('base64');
        
        const data = {
            message: message,
            content: encodedContent,
            sha: sha,
            branch: 'main'
        };

        return await this.request(url, 'PUT', data);
    }

    async deleteFile(path, sha, message) {
        const url = `/repos/${this.owner}/${this.repoName}/contents/${path}`;
        
        const data = {
            message: message,
            sha: sha,
            branch: 'main'
        };

        return await this.request(url, 'DELETE', data);
    }

    async listBranches() {
        const url = `/repos/${this.owner}/${this.repoName}/branches`;
        return await this.request(url);
    }
}

module.exports = new GitHubService();