// server/utils/fileUtils.js
const path = require('path');

const MIME_TYPES = {
    // Text files
    '.txt': 'text/plain',
    '.md': 'text/markdown',
    '.json': 'application/json',
    '.js': 'application/javascript',
    '.ts': 'application/typescript',
    '.html': 'text/html',
    '.css': 'text/css',
    '.xml': 'application/xml',
    '.yaml': 'text/yaml',
    '.yml': 'text/yaml',
    
    // Images
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    
    // Documents
    '.pdf': 'application/pdf',
    
    // Archives
    '.zip': 'application/zip',
    '.tar': 'application/x-tar',
    '.gz': 'application/gzip',
    
    // Code
    '.py': 'text/x-python',
    '.java': 'text/x-java-source',
    '.c': 'text/x-c',
    '.cpp': 'text/x-c++',
    '.go': 'text/x-go',
    '.rs': 'text/x-rust'
};

module.exports = {
    getMimeType(filename) {
        const ext = path.extname(filename).toLowerCase();
        return MIME_TYPES[ext] || 'application/octet-stream';
    },

    isTextFile(filename) {
        const textTypes = ['.txt', '.md', '.json', '.js', '.ts', '.html', '.css', 
                          '.xml', '.yaml', '.yml', '.py', '.java', '.c', '.cpp',
                          '.go', '.rs', '.php', '.rb', '.swift', '.kt'];
        const ext = path.extname(filename).toLowerCase();
        return textTypes.includes(ext);
    },

    isImageFile(filename) {
        const imageTypes = ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.bmp', '.webp'];
        const ext = path.extname(filename).toLowerCase();
        return imageTypes.includes(ext);
    },

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    getFileIcon(filename, type) {
        if (type === 'directory') return 'folder';
        
        const ext = path.extname(filename).toLowerCase();
        const iconMap = {
            '.js': 'javascript',
            '.ts': 'typescript',
            '.html': 'html',
            '.css': 'css',
            '.json': 'json',
            '.md': 'markdown',
            '.py': 'python',
            '.java': 'java',
            '.png': 'image',
            '.jpg': 'image',
            '.pdf': 'pdf',
            '.zip': 'zip'
        };
        
        return iconMap[ext] || 'file';
    }
};