// server/utils/pathUtils.js
const path = require('path');

const BASE_PATH = '/storage/emulated/0';

module.exports = {
    sanitizePath(inputPath) {
        // Resolve to absolute path
        let resolved = path.resolve(inputPath);
        
        // Check for traversal attempts
        if (!resolved.startsWith(BASE_PATH)) {
            throw new Error('Access denied: path outside allowed directory');
        }
        
        return resolved;
    },

    isValidPath(inputPath) {
        try {
            this.sanitizePath(inputPath);
            return true;
        } catch {
            return false;
        }
    },

    getRelativePath(absolutePath) {
        return path.relative(BASE_PATH, absolutePath);
    },

    joinPaths(...segments) {
        return path.join(...segments);
    }
};