const fs = require('fs').promises;
const path = require('path');

/**
 * Resilience utilities for handling failures and recovery
 */
class ResilienceManager {
    constructor(options = {}) {
        this.checkpointDir = options.checkpointDir || './checkpoints';
        this.maxRetries = options.maxRetries || 3;
        this.retryDelay = options.retryDelay || 1000;
        this.checkpoints = new Map();
    }

    /**
     * Execute function with retry logic
     */
    async withRetry(operation, context = {}) {
        let lastError;
        
        for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
            try {
                return await operation();
            } catch (error) {
                lastError = error;
                
                // Check if error is retryable
                if (!this.isRetryableError(error)) {
                    throw error;
                }
                
                if (attempt < this.maxRetries) {
                    const delay = this.retryDelay * Math.pow(2, attempt - 1);
                    console.log(`[Retry ${attempt}/${this.maxRetries}] ${context.name || 'operation'} failed, retrying in ${delay}ms...`);
                    await this.sleep(delay);
                }
            }
        }
        
        throw lastError;
    }

    /**
     * Check if error should be retried
     */
    isRetryableError(error) {
        // Network errors, rate limits, temporary failures
        const retryableCodes = ['ECONNRESET', 'ETIMEDOUT', 'ECONNREFUSED', 'EPIPE'];
        const retryableStatuses = [408, 429, 500, 502, 503, 504];
        
        if (error.code && retryableCodes.includes(error.code)) return true;
        if (error.status && retryableStatuses.includes(error.status)) return true;
        
        return false;
    }

    /**
     * Create checkpoint for resumable operation
     */
    async createCheckpoint(id, state) {
        const checkpointPath = path.join(this.checkpointDir, `${id}.json`);
        
        try {
            await fs.mkdir(this.checkpointDir, { recursive: true });
            await fs.writeFile(checkpointPath, JSON.stringify({
                ...state,
                timestamp: Date.now(),
                version: 1
            }));
            
            this.checkpoints.set(id, state);
            return true;
        } catch (error) {
            console.error('Failed to create checkpoint:', error);
            return false;
        }
    }

    /**
     * Load checkpoint
     */
    async loadCheckpoint(id) {
        // Check memory first
        if (this.checkpoints.has(id)) {
            return this.checkpoints.get(id);
        }
        
        // Load from disk
        const checkpointPath = path.join(this.checkpointDir, `${id}.json`);
        
        try {
            const data = await fs.readFile(checkpointPath, 'utf-8');
            const state = JSON.parse(data);
            this.checkpoints.set(id, state);
            return state;
        } catch (error) {
            return null;
        }
    }

    /**
     * Clear checkpoint
     */
    async clearCheckpoint(id) {
        this.checkpoints.delete(id);
        
        const checkpointPath = path.join(this.checkpointDir, `${id}.json`);
        try {
            await fs.unlink(checkpointPath);
        } catch (error) {
            // Ignore if doesn't exist
        }
    }

    /**
     * Resume transfer from checkpoint
     */
    async resumeTransfer(checkpointId, transferFunction) {
        const checkpoint = await this.loadCheckpoint(checkpointId);
        
        if (!checkpoint) {
            throw new Error('No checkpoint found for transfer');
        }
        
        console.log(`[Resume] Resuming transfer from checkpoint: ${checkpointId}`);
        
        // Update checkpoint with resume attempt
        checkpoint.resumeCount = (checkpoint.resumeCount || 0) + 1;
        checkpoint.lastResume = Date.now();
        
        await this.createCheckpoint(checkpointId, checkpoint);
        
        // Execute transfer with checkpoint context
        return await transferFunction(checkpoint);
    }

    /**
     * Circuit breaker pattern for failing services
     */
    createCircuitBreaker(options = {}) {
        const threshold = options.failureThreshold || 5;
        const timeout = options.resetTimeout || 30000;
        
        let failures = 0;
        let lastFailure = null;
        let state = 'CLOSED'; // CLOSED, OPEN, HALF_OPEN
        
        return async (operation) => {
            if (state === 'OPEN') {
                if (Date.now() - lastFailure > timeout) {
                    state = 'HALF_OPEN';
                } else {
                    throw new Error('Circuit breaker is OPEN');
                }
            }
            
            try {
                const result = await operation();
                
                if (state === 'HALF_OPEN') {
                    state = 'CLOSED';
                    failures = 0;
                }
                
                return result;
            } catch (error) {
                failures++;
                lastFailure = Date.now();
                
                if (failures >= threshold) {
                    state = 'OPEN';
                }
                
                throw error;
            }
        };
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

module.exports = new ResilienceManager();
```

---

## MODULE 10: Project Tree Caching

```javascript