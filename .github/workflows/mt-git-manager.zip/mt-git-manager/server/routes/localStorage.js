// server/routes/localStorage.js
const express = require('express');
const router = express.Router();
const filesystemService = require('../services/filesystemService');

// GET /api/local/list?path=/storage/emulated/0/Documents
router.get('/list', async (req, res) => {
    try {
        const { path: dirPath } = req.query;
        
        if (!dirPath) {
            return res.status(400).json({
                success: false,
                error: 'Path parameter required'
            });
        }

        const files = await filesystemService.listDirectory(dirPath);
        
        res.json({
            success: true,
            path: dirPath,
            files: files
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// GET /api/local/read?path=/storage/emulated/0/file.txt
router.get('/read', async (req, res) => {
    try {
        const { path: filePath } = req.query;
        
        if (!filePath) {
            return res.status(400).json({
                success: false,
                error: 'Path parameter required'
            });
        }

        const content = await filesystemService.readFile(filePath);
        
        // Set content type based on file extension
        const ext = filePath.split('.').pop().toLowerCase();
        const mimeTypes = {
            'txt': 'text/plain',
            'json': 'application/json',
            'js': 'application/javascript',
            'html': 'text/html',
            'css': 'text/css',
            'md': 'text/markdown'
        };
        
        res.setHeader('Content-Type', mimeTypes[ext] || 'text/plain');
        res.send(content);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/local/write
router.post('/write', async (req, res) => {
    try {
        const { path: filePath, content } = req.body;
        
        if (!filePath || content === undefined) {
            return res.status(400).json({
                success: false,
                error: 'Path and content required'
            });
        }

        await filesystemService.writeFile(filePath, content);
        
        res.json({
            success: true,
            message: 'File written successfully',
            path: filePath
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/local/delete
router.post('/delete', async (req, res) => {
    try {
        const { path: targetPath } = req.body;
        
        if (!targetPath) {
            return res.status(400).json({
                success: false,
                error: 'Path required'
            });
        }

        await filesystemService.deleteFile(targetPath);
        
        res.json({
            success: true,
            message: 'Deleted successfully',
            path: targetPath
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/local/rename
router.post('/rename', async (req, res) => {
    try {
        const { oldPath, newPath } = req.body;
        
        if (!oldPath || !newPath) {
            return res.status(400).json({
                success: false,
                error: 'Both oldPath and newPath required'
            });
        }

        await filesystemService.renameFile(oldPath, newPath);
        
        res.json({
            success: true,
            message: 'Renamed successfully',
            oldPath,
            newPath
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/local/mkdir
router.post('/mkdir', async (req, res) => {
    try {
        const { path: dirPath } = req.body;
        
        if (!dirPath) {
            return res.status(400).json({
                success: false,
                error: 'Path required'
            });
        }

        await filesystemService.createDirectory(dirPath);
        
        res.json({
            success: true,
            message: 'Directory created successfully',
            path: dirPath
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// GET /api/local/download?path=...
router.get('/download', async (req, res) => {
    try {
        const { path: filePath } = req.query;
        
        if (!filePath) {
            return res.status(400).json({
                success: false,
                error: 'Path parameter required'
            });
        }

        const fileName = filePath.split('/').pop();
        const content = await filesystemService.readFile(filePath);
        
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.setHeader('Content-Type', 'application/octet-stream');
        res.send(content);
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;