// server/routes/transfer.js
const express = require('express');
const router = express.Router();
const filesystemService = require('../services/filesystemService');
const githubService = require('../services/githubService');

// POST /api/transfer/local-to-github
router.post('/local-to-github', async (req, res) => {
    try {
        const { localPath, githubPath, message } = req.body;
        
        if (!localPath || !githubPath) {
            return res.status(400).json({
                success: false,
                error: 'Both localPath and githubPath required'
            });
        }

        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'GitHub not connected'
            });
        }

        // Step 1: Read local file
        console.log(`[Transfer] Reading local file: ${localPath}`);
        const content = await filesystemService.readFile(localPath);
        
        // Step 2: Check if file exists on GitHub (for update vs create)
        let sha = null;
        try {
            const existingFile = await githubService.getFileInfo(githubPath);
            sha = existingFile.sha;
        } catch (err) {
            // File doesn't exist, will create new
        }

        // Step 3: Transfer to GitHub
        console.log(`[Transfer] Writing to GitHub: ${githubPath}`);
        let result;
        const commitMessage = message || `Transfer ${localPath.split('/').pop()} via MT-Git Manager`;
        
        if (sha) {
            // Update existing
            result = await githubService.updateFile(githubPath, content, sha, commitMessage);
        } else {
            // Create new
            result = await githubService.createFile(githubPath, content, commitMessage);
        }

        res.json({
            success: true,
            message: 'Transfer completed successfully',
            source: localPath,
            destination: githubPath,
            commit: result.commit
        });
    } catch (error) {
        console.error('[Transfer Error]', error);
        res.status(500).json({
            success: false,
            error: error.message,
            stage: error.stage || 'unknown'
        });
    }
});

// POST /api/transfer/github-to-local
router.post('/github-to-local', async (req, res) => {
    try {
        const { githubPath, localPath } = req.body;
        
        if (!githubPath || !localPath) {
            return res.status(400).json({
                success: false,
                error: 'Both githubPath and localPath required'
            });
        }

        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'GitHub not connected'
            });
        }

        // Step 1: Fetch from GitHub
        console.log(`[Transfer] Fetching from GitHub: ${githubPath}`);
        const content = await githubService.getFileContent(githubPath);
        
        // Step 2: Write to local storage
        console.log(`[Transfer] Writing to local: ${localPath}`);
        await filesystemService.writeFile(localPath, content);

        res.json({
            success: true,
            message: 'Transfer completed successfully',
            source: githubPath,
            destination: localPath
        });
    } catch (error) {
        console.error('[Transfer Error]', error);
        res.status(500).json({
            success: false,
            error: error.message,
            stage: error.stage || 'unknown'
        });
    }
});

// POST /api/transfer/batch
router.post('/batch', async (req, res) => {
    try {
        const { operations } = req.body;
        
        if (!Array.isArray(operations)) {
            return res.status(400).json({
                success: false,
                error: 'Operations array required'
            });
        }

        const results = [];
        const errors = [];

        for (const op of operations) {
            try {
                if (op.direction === 'local-to-github') {
                    const content = await filesystemService.readFile(op.source);
                    let sha = null;
                    try {
                        const info = await githubService.getFileInfo(op.destination);
                        sha = info.sha;
                    } catch (e) {}
                    
                    if (sha) {
                        await githubService.updateFile(op.destination, content, sha, op.message);
                    } else {
                        await githubService.createFile(op.destination, content, op.message);
                    }
                } else {
                    const content = await githubService.getFileContent(op.source);
                    await filesystemService.writeFile(op.destination, content);
                }
                results.push({ success: true, operation: op });
            } catch (err) {
                errors.push({ success: false, operation: op, error: err.message });
            }
        }

        res.json({
            success: errors.length === 0,
            completed: results.length,
            failed: errors.length,
            results,
            errors
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;