// server/routes/github.js
const express = require('express');
const router = express.Router();
const githubService = require('../services/githubService');

// POST /api/github/connect
router.post('/connect', async (req, res) => {
    try {
        const { token, repo } = req.body;
        
        if (!token || !repo) {
            return res.status(400).json({
                success: false,
                error: 'Token and repo (owner/name) required'
            });
        }

        // Validate connection by fetching repo info
        const repoInfo = await githubService.validateConnection(token, repo);
        
        // Store credentials in service (memory only)
        githubService.setCredentials(token, repo);
        
        res.json({
            success: true,
            message: 'Connected to GitHub successfully',
            repo: repoInfo
        });
    } catch (error) {
        res.status(401).json({
            success: false,
            error: error.message
        });
    }
});

// GET /api/github/list?path=
router.get('/list', async (req, res) => {
    try {
        const { path = '' } = req.query;
        
        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'Not connected to GitHub. Call /connect first.'
            });
        }

        const files = await githubService.listContents(path);
        
        res.json({
            success: true,
            path: path,
            files: files
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// GET /api/github/read?path=
router.get('/read', async (req, res) => {
    try {
        const { path } = req.query;
        
        if (!path) {
            return res.status(400).json({
                success: false,
                error: 'Path parameter required'
            });
        }

        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'Not connected to GitHub'
            });
        }

        const content = await githubService.getFileContent(path);
        
        res.json({
            success: true,
            path: path,
            content: content,
            encoding: 'utf-8'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/github/create
router.post('/create', async (req, res) => {
    try {
        const { path: filePath, content, message = `Create ${filePath} via MT-Git Manager` } = req.body;
        
        if (!filePath || content === undefined) {
            return res.status(400).json({
                success: false,
                error: 'Path and content required'
            });
        }

        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'Not connected to GitHub'
            });
        }

        const result = await githubService.createFile(filePath, content, message);
        
        res.json({
            success: true,
            message: 'File created successfully',
            commit: result.commit,
            content: result.content
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/github/update
router.post('/update', async (req, res) => {
    try {
        const { path: filePath, content, sha, message = `Update ${filePath} via MT-Git Manager` } = req.body;
        
        if (!filePath || content === undefined || !sha) {
            return res.status(400).json({
                success: false,
                error: 'Path, content, and sha required'
            });
        }

        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'Not connected to GitHub'
            });
        }

        const result = await githubService.updateFile(filePath, content, sha, message);
        
        res.json({
            success: true,
            message: 'File updated successfully',
            commit: result.commit,
            content: result.content
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// POST /api/github/delete
router.post('/delete', async (req, res) => {
    try {
        const { path: filePath, sha, message = `Delete ${filePath} via MT-Git Manager` } = req.body;
        
        if (!filePath || !sha) {
            return res.status(400).json({
                success: false,
                error: 'Path and sha required'
            });
        }

        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'Not connected to GitHub'
            });
        }

        const result = await githubService.deleteFile(filePath, sha, message);
        
        res.json({
            success: true,
            message: 'File deleted successfully',
            commit: result.commit
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// GET /api/github/branches
router.get('/branches', async (req, res) => {
    try {
        if (!githubService.isConnected()) {
            return res.status(401).json({
                success: false,
                error: 'Not connected to GitHub'
            });
        }

        const branches = await githubService.listBranches();
        
        res.json({
            success: true,
            branches: branches
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

module.exports = router;