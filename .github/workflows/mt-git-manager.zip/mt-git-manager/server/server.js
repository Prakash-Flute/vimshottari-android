// server/server.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;

const localStorageRoutes = require('./routes/localStorage');
const githubRoutes = require('./routes/github');
const transferRoutes = require('./routes/transfer');

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Request logging
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// API Routes
app.use('/api/local', localStorageRoutes);
app.use('/api/github', githubRoutes);
app.use('/api/transfer', transferRoutes);

// Serve static frontend files
app.use(express.static(path.join(__dirname, '../client')));

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({
        success: false,
        error: err.message || 'Internal server error'
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint not found'
    });
});

app.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════╗
║           MT-Git Manager Server v1.0                   ║
║                                                        ║
║  Local Filesystem: /storage/emulated/0                 ║
║  Server Address: http://localhost:${PORT}                  ║
║                                                        ║
║  Endpoints:                                            ║
║  - Local Storage: /api/local/*                         ║
║  - GitHub: /api/github/*                               ║
║  - Transfer: /api/transfer/*                           ║
╚════════════════════════════════════════════════════════╝
    `);
});

module.exports = app;